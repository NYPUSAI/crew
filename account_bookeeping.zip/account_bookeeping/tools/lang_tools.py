import json
import os
import requests
import sqlite3
from langchain.tools import tool

# SQL Database Tool
class FinancialSQLTools:
    
    @tool("Query the financial SQL database")
    def query_sql_database(query: str, db_path: str):
        """Useful for querying internal financial databases like general ledgers or transaction records."""
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute(query)
            results = cursor.fetchall()
            conn.close()
            return results if results else "No records found."
        except Exception as e:
            return f"Error querying the database: {e}"


# Zapier Webhook Automation Tool
class ZapierAutomationTools:

    @tool("Automate financial workflows via Zapier")
    def trigger_zapier_workflow(event_type: str, data: dict):
        """Useful for automating tasks like invoice generation or sending payment reminders via Zapier Webhooks."""
        zapier_webhook_url = os.getenv('ZAPIER_WEBHOOK_URL')  # Set your Zapier webhook URL in environment variables
        
        payload = {
            "event_type": event_type,
            "data": data
        }
        
        try:
            response = requests.post(zapier_webhook_url, json=payload)
            if response.status_code == 200:
                return "Zapier workflow triggered successfully."
            else:
                return f"Failed to trigger Zapier workflow. Status Code: {response.status_code}"
        except Exception as e:
            return f"Error triggering Zapier workflow: {e}"


# Google Sheets API Tool using gspread
class GoogleSheetsTools:

    @tool("Interact with Google Sheets")
    def fetch_update_google_sheets(sheet_id: str, worksheet_name: str, action: str, data: dict = None):
        """Fetch or update financial records stored in Google Sheets.
        Action can be 'fetch' or 'update'.
        """
        import gspread
        from oauth2client.service_account import ServiceAccountCredentials

        # Authenticate with Google API
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        creds = ServiceAccountCredentials.from_json_keyfile_name(os.getenv('GOOGLE_SHEETS_CREDENTIALS'), scope)
        client = gspread.authorize(creds)

        try:
            sheet = client.open_by_key(sheet_id)
            worksheet = sheet.worksheet(worksheet_name)

            if action == "fetch":
                records = worksheet.get_all_records()
                return records
            elif action == "update" and data:
                for row in data:
                    worksheet.append_row(row)
                return "Data updated successfully."
            else:
                return "Invalid action or missing data."
        except Exception as e:
            return f"Error interacting with Google Sheets: {e}"
