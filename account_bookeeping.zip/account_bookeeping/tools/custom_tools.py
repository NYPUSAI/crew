import json
import os
import requests
from datetime import datetime
from langchain.tools import tool
import pandas as pd

class CustomFinancialTools:

    @tool("Fetch real-time bank transactions")
    def fetch_bank_transactions(account_id, start_date, end_date):
        """Fetches real-time bank transactions using a custom bank API for reconciliation purposes."""
        api_url = os.getenv('BANK_API_URL')
        api_key = os.getenv('BANK_API_KEY')
        
        if not api_url or not api_key:
            return "Bank API credentials are missing. Please set BANK_API_URL and BANK_API_KEY in environment variables."

        payload = json.dumps({
            "account_id": account_id,
            "start_date": start_date,
            "end_date": end_date
        })
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }

        response = requests.post(f"{api_url}/transactions", headers=headers, data=payload)
        
        if response.status_code != 200:
            return f"Failed to fetch transactions. Status code: {response.status_code}, Response: {response.text}"

        transactions = response.json()
        return transactions

    @tool("Generate invoice template")
    def generate_invoice(client_details, items, output_path="invoice_template.json"):
        """Automatically generates an invoice template based on client details and itemized billing."""
        invoice = {
            "invoice_id": f"INV-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "date": datetime.now().strftime('%Y-%m-%d'),
            "client_details": client_details,
            "items": items,
            "total_amount": sum(item['quantity'] * item['unit_price'] for item in items)
        }

        with open(output_path, 'w') as file:
            json.dump(invoice, file, indent=4)

        return f"Invoice generated and saved to {output_path}"

    @tool("Automate payroll calculations")
    def automate_payroll(payroll_data_path, tax_deductions_path, output_path="processed_payroll.xlsx"):
        """Calculates salaries, deductions, and tax payments automatically from payroll data."""
        # Load payroll data
        payroll_df = pd.read_excel(payroll_data_path)
        with open(tax_deductions_path, 'r') as file:
            tax_deductions = json.load(file)

        # Apply tax deductions
        payroll_df['Tax Deduction'] = payroll_df['Gross Salary'] * tax_deductions['tax_rate']
        payroll_df['Net Salary'] = payroll_df['Gross Salary'] - payroll_df['Tax Deduction']

        # Save processed payroll
        payroll_df.to_excel(output_path, index=False)
        return f"Payroll processed and saved to {output_path}"

# Example Usage:
# CustomFinancialTools.fetch_bank_transactions("12345", "2025-02-01", "2025-02-28")
# CustomFinancialTools.generate_invoice({"name": "XYZ Corp", "address": "123 Main St"}, [{"description": "Consulting", "quantity": 5, "unit_price": 100}])
# CustomFinancialTools.automate_payroll("path/to/payroll.xlsx", "path/to/tax_deductions.json")