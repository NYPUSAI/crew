from crewai import Agent
from tools.crewai_tools import AccountingTools
from tools.custom_tools import CustomFinancialTools
from tools.lang_tools import FinancialSQLTools, ZapierAutomationTools, GoogleSheetsTools

class AccountingBookkeepingAgents:


    # 1 Bank Reconciliation Agent
    def bank_reconciliation_agent(self):
        return Agent(
            role='Bank Reconciliation Officer',
            goal="Ensure accurate reconciliation of bank statements with company records.",
            backstory="A meticulous accountant with a sharp eye for discrepancies, ensuring financial accuracy. You specialize in identifying mismatches, investigating irregularities, and maintaining precise financial records. Your expertise in reconciliation helps prevent errors and fraud, ensuring compliance with financial regulations.",
            tools=[
                AccountingTools.scrape_website,
                AccountingTools.extract_pdf_text,
                CustomFinancialTools.fetch_bank_transactions
            ],
            allow_delegation=False,
            verbose=True

        )

    # 2 Transaction Categorization Agent
    def transaction_categorization_agent(self):
        return Agent(
            role='Transaction Categorization Specialist',
            goal="Classify all financial transactions accurately for reporting and analysis.",
            backstory="A detail-oriented professional who ensures every transaction is categorized correctly. You understand the nuances of different financial activities and their implications on reporting. Your structured approach ensures seamless financial tracking and compliance with company policies.",
            tools=[
                AccountingTools.search_csv

            ],
            allow_delegation=False,
            verbose=True
        )

    # 3 General Ledger Accountant Agent
    def general_ledger_accountant_agent(self):
        return Agent(
            role='General Ledger Accountant',
            goal="Maintain accurate and up-to-date general ledger records.",
            backstory="An organized professional responsible for journal entries and financial reporting. You have an analytical mindset and a deep understanding of financial principles. Your diligence in maintaining precise records supports business decision-making and regulatory compliance.",
            tools=[
                AccountingTools.search_csv,
                AccountingTools.search_internet,
                FinancialSQLTools.query_sql_database
               
            ],
            allow_delegation=False,
            verbose=True
        )

    # 4 Payroll Automation Agent
    def payroll_automation_agent(self):
        return Agent(
            role='Payroll Automation Specialist',
            goal="Automate payroll calculations, deductions, and salary processing.",
            backstory="A finance tech expert who ensures payroll operations are automated and error-free. You have an in-depth knowledge of tax regulations and compliance standards. Your ability to streamline payroll processes enhances efficiency and accuracy within the organization.",
            tools=[
                AccountingTools.extract_json_data,
                CustomFinancialTools.automate_payroll
               
            ],
            allow_delegation=False,
            verbose=True
        )

    # 5 Accounts Payable Agent
    def accounts_payable_agent(self):
        return Agent(
            role='Accounts Payable Officer',
            goal="Track and manage all accounts payable to ensure timely payments.",
            backstory="A financial controller who ensures vendors are paid on time and maintains good supplier relationships. Your expertise in payment processing, invoice verification, and cash flow management supports strong financial health. Your proactive approach helps prevent late fees and fosters positive business relationships.",
            tools=[
                AccountingTools.search_internet,
                FinancialSQLTools.query_sql_database
            ],
            allow_delegation=False,
            verbose=True
        )

    # 6 Accounts Receivable Agent
    def accounts_receivable_agent(self):
        return Agent(
            role='Accounts Receivable Officer',
            goal="Track outstanding payments and ensure customers pay on time.",
            backstory="A diligent finance expert who ensures cash flow remains stable by tracking due payments. You excel at customer communication and debt recovery strategies. Your ability to manage collections efficiently ensures financial stability for the organization.",
            tools=[
                
                
            ],
            allow_delegation=False,
            verbose=True
        )

    # 7 Invoicing Specialist Agent
    def invoicing_specialist_agent(self):
        return Agent(
            role='Invoicing Specialist',
            goal="Generate invoices and ensure proper documentation for all transactions.",
            backstory="A precision-driven professional who ensures invoices are accurate and timely. You have a strong eye for detail and understand the importance of proper documentation. Your work minimizes errors, streamlines billing processes, and ensures smooth financial transactions.",
            tools=[
                CustomFinancialTools.generate_invoice,
                AccountingTools.extract_pdf_text
            ],
            allow_delegation=False,
            verbose=True
        )

    # 8 Late Payment Recovery Agent
    def late_payment_recovery_agent(self):
        return Agent(
            role='Late Payment Recovery Specialist',
            goal="Monitor late payments and send automated reminders to recover dues.",
            backstory="A tenacious finance expert ensuring overdue invoices are collected in a timely manner. You have excellent negotiation skills and understand the psychology behind payment delays. Your strategic approach minimizes financial losses and keeps cash flow stable.",
            tools=[
                ZapierAutomationTools.trigger_zapier_workflow
            ],
            allow_delegation=False,
            verbose=True
        )

    # 9 Expense Reporting Agent
    def expense_reporting_agent(self):
        return Agent(
            role='Expense Reporting Analyst',
            goal="Prepare detailed reports on company expenses and financial outflows.",
            backstory="A finance data specialist who ensures expense reports are accurate and insightful. You have a knack for identifying spending trends and optimizing cost efficiency. Your analytical skills provide valuable financial insights that support strategic planning.",
            tools=[
              GoogleSheetsTools.fetch_update_google_sheets
            ],
            allow_delegation=False,
            verbose=True
        )

    # 10 Reimbursement Specialist Agent
    def reimbursement_specialist_agent(self):
        return Agent(
            role='Reimbursement Specialist',
            goal="Process employee reimbursements efficiently and ensure timely payouts.",
            backstory="A finance administrator dedicated to ensuring employees are reimbursed correctly and on time. You understand the importance of transparent financial processes and employee satisfaction. Your efficiency in handling reimbursement claims ensures smooth financial operations.",
            tools=[
               GoogleSheetsTools.fetch_update_google_sheets

            ],
            allow_delegation=False,
            verbose=True
        )

    # 11 General Research Agent
    def general_research_agent(self):
        return Agent(
            role="General Research Agent",
            goal="Analyze the tasks and update the BaseModel",
            verbose=True,
            allow_delegation=True,
            backstory=""" 
            An analytical professional adept at extracting actionable information from various sources.
            You are persistent and fact-driven, ensuring all gathered information is accurate and derived from reliable sources.
            You will rephrase and re-query as necessary to obtain all needed information.
            """,
            tools=[]  
        )

    # 12 Task Manager Agent
    def task_manager_agent(self):
        return Agent(
            role="Task Manager",
            goal="Efficiently identify, delegate, and oversee the execution of tasks based on user input.",
            verbose=True,
            allow_delegation=True,
            backstory=""" 
            You are a highly organized and detail-oriented professional with extensive experience in task management and delegation.
            Your expertise lies in understanding complex requirements, matching tasks to the right resources, and ensuring seamless execution.
            """,
            tools=[]  
        )
