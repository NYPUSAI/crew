from pydantic import BaseModel, Field
from crewai import Task
from typing import Optional, List, Dict, Literal
from langchain.tools import BaseTool

class FinancialReport(BaseModel):
    account_name: str
    total_revenue: float
    expenses: float
    profit: float

class Transaction(BaseModel):
    date: str
    description: str
    amount: float
    category: str

class BankReconciliationReport(BaseModel):
    total_balance: float
    ledger_balance: float
    unmatched_transactions: int
    adjustments_required: str

class Invoice(BaseModel):
    invoice_number: str
    client_name: str
    amount_due: float
    due_date: str

class ExpenseReport(BaseModel):
    total_expenses: float
    breakdown: dict
    recommendations: str

class Payroll(BaseModel):
    employee_name: str
    salary: float
    deductions: float
    net_salary: float

class TaskStatusUpdateSchema(BaseModel):
    task_name: str = Field(..., description="The name of the task being updated.")
    status: Literal["COMPLETED", "PENDING"] = Field(..., description="Task status must be 'COMPLETED' or 'PENDING'.")
    chat_message_id: int = Field(..., description="The ID of the chat message associated with the task.")

class TaskStatusUpdate(BaseTool):
    name: str = "task_status_update"
    description: str = "Updates the task status dynamically to either 'COMPLETED' or 'PENDING' along with the task name and chat message ID."
    args_schema = TaskStatusUpdateSchema

    def _run(self, task_name: str, status: str, chat_message_id: int) -> str:
        print(f"Updated Task: {task_name} | Status: {status} for Chat Message ID: {chat_message_id}")
        return f"Task '{task_name}' status updated successfully to {status}" 


class AccountingBookkeepingTaskStatus(BaseModel):
    bank_reconciliation_task_status: Optional[str] = Field(None, description="Status of the Bank Reconciliation task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    transaction_categorization_task_status: Optional[str] = Field(None, description="Status of the Transaction Categorization task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    general_ledger_entry_task_status: Optional[str] = Field(None, description="Status of the General Ledger Entry task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    payroll_automation_task_status: Optional[str] = Field(None, description="Status of the Payroll Automation task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    accounts_payable_task_status: Optional[str] = Field(None, description="Status of the Accounts Payable task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    accounts_receivable_task_status: Optional[str] = Field(None, description="Status of the Accounts Receivable task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    invoice_generation_task_status: Optional[str] = Field(None, description="Status of the Invoice Generation task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    late_payment_reminder_task_status: Optional[str] = Field(None, description="Status of the Late Payment Reminder task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    expense_reporting_task_status: Optional[str] = Field(None, description="Status of the Expense Reporting task (e.g., COMPLETED, IN_PROGRESS, FAILED)")
    reimbursement_processing_task_status: Optional[str] = Field(None, description="Status of the Reimbursement Processing task (e.g., COMPLETED, IN_PROGRESS, FAILED)")

class AccountingBookkeepingTasks():
    def bank_reconciliation_task(self, agent, chat_message_id):
        return Task(
            description='Perform bank reconciliation by matching transactions from bank statements with company records.',
            agent=agent,
            async_execution=True,
            expected_output='''BankReconciliationReport(
                total_balance=50000.0,
                ledger_balance=49000.0,
                unmatched_transactions=3,
                adjustments_required="Adjust for outstanding checks #1002, #1003"
            )''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def transaction_categorization_task(self, agent, chat_message_id):
        return Task(
            description='Categorize financial transactions based on predefined accounting rules.',
            agent=agent,
            async_execution=True,
            expected_output=''''[
                Transaction(date="2025-01-01", description="Office Rent", amount=2000.0, category="Expense"),
                Transaction(date="2025-01-02", description="Product Sales", amount=5000.0, category="Revenue")
            ]''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def general_ledger_entry_task(self, agent, chat_message_id):
        return Task(
            description='Record financial transactions in the general ledger.',
            agent=agent,
            async_execution=True,
            expected_output="""General ledger entries have been made and classified accurately as per accounting standards.""",
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def payroll_automation_task(self, agent, chat_message_id):
        return Task(
            description='Automate payroll calculations for employees including salary, deductions, and net pay.',
            agent=agent,
            async_execution=True,
            expected_output='''Payroll(employee_name="John Doe", salary=3000.0, deductions=450.0, net_salary=2550.0),''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def accounts_payable_task(self, agent, chat_message_id):
        return Task(
            description='Track and record accounts payable transactions, ensuring timely payments to vendors.',
            agent=agent,
            async_execution=True,
            expected_output="""Accounts Payable:
                              - Vendor: ABC Corp, Amount: $1500, Due Date: 2025-02-15
                              - Vendor: XYZ Ltd, Amount: $2000, Due Date: 2025-02-20""",
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def accounts_receivable_task(self, agent, chat_message_id):
        return Task(
            description='Track and record accounts receivable transactions, ensuring timely collections from customers.',
            agent=agent,
            async_execution=True,
            expected_output="""Accounts Receivable:
                              - Client: Company A, Amount Due: $3000, Due Date: 2025-02-01
                              - Client: Company B, Amount Due: $4500, Due Date: 2025-02-10""",
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def invoice_generation_task(self, agent, chat_message_id):
        return Task(
            description='Generate invoices for clients based on completed transactions or services provided.',
            agent=agent,
            async_execution=True,
            expected_output='''Invoice(invoice_number="INV-001", client_name="Company A", amount_due=3000.0, due_date="2025-02-01")''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def late_payment_reminder_task(self, agent, chat_message_id):
        return Task(
            description='Monitor late payments and send reminders to clients.',
            agent=agent,
            async_execution=True,
            expected_output="""Late Payment Reminder Sent:
                              - Client: Company A, Amount Due: $3000, Reminder Date: 2025-01-31""",
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def expense_reporting_task(self, agent, chat_message_id):
        return Task(
            description='Prepare monthly expense reports, categorizing expenses and providing actionable insights.',
            agent=agent,
            async_execution=True,
            expected_output='''ExpenseReport(
                total_expenses=15000.0,
                breakdown={"Salaries": 8000.0, "Rent": 2000.0, "Utilities": 1000.0},
                recommendations="Reduce marketing expenses by 10% in Q2"
            )''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def reimbursement_processing_task(self, agent, chat_message_id):
        return Task(
            description='Process employee reimbursement claims and ensure proper documentation and approval.',
            agent=agent,
            async_execution=True,
            expected_output="""Reimbursement Processed:
                              - Employee: Jane Smith, Amount: $200, Reason: Business Travel""",
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    
    def find_initial_information_task(self, agent,  chat_message_id):
        return Task(
        description="""
            Ensure to track and update the `task_status` for each agent dynamically.
            Ensure to fill out the required information about the agents' progress.
            You must update the `task_status` for each task dynamically based on completion.

            class AccountingBookkeepingTaskStatus(BaseModel):
                bank_reconciliation_task_status: Optional[str]
                transaction_categorization_task_status: Optional[str]
                general_ledger_entry_task_status: Optional[str]
                payroll_automation_task_status: Optional[str]
                accounts_payable_task_status: Optional[str]
                accounts_receivable_task_status: Optional[str]
                invoice_generation_task_status: Optional[str]
                late_payment_reminder_task_status: Optional[str]
                expense_reporting_task_status: Optional[str]
                reimbursement_processing_task_status: Optional[str]

            If any agent's task is completed, update their `task_status` to "COMPLETED".
            If any agent fails, update their `task_status` to "FAILED".

            If the financial data is missing, update all tasks from transaction categorization as "FAILED".
        """,
        agent=agent,
        expected_output="""
            - Dynamically update the `AccountingBookkeepingTaskStatus` model with the latest task status.
            - If any information is unavailable, leave it as "FAILED".
        """,
    
        chat_message_id=chat_message_id
    )

    