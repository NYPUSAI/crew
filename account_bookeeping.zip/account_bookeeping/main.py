from crewai import Crew, Process
from langchain_openai import ChatOpenAI
from agents import AccountingBookkeepingAgents
from tasks import AccountingBookkeepingTasks
from dotenv import load_dotenv
from crewai import Task


load_dotenv()


# Initialize the agents and tasks
agents = AccountingBookkeepingAgents()
tasks = AccountingBookkeepingTasks()


# Initialize the OpenAI GPT-3.5 language model
manager_llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7)

# Instantiate the agents
bank_reconciliation_agent = agents.bank_reconciliation_agent()
transaction_categorization_agent = agents.transaction_categorization_agent()
general_ledger_accountant_agent = agents.general_ledger_accountant_agent()
payroll_automation_agent = agents.payroll_automation_agent()
accounts_payable_agent = agents.accounts_payable_agent()
accounts_receivable_agent = agents.accounts_receivable_agent()
invoicing_specialist_agent = agents.invoicing_specialist_agent()
late_payment_recovery_agent = agents.late_payment_recovery_agent()
expense_reporting_agent = agents.expense_reporting_agent()
reimbursement_specialist_agent = agents.reimbursement_specialist_agent()
general_research_agent = agents.general_research_agent()
task_manager_agent = agents.task_manager_agent()

# Instantiate the tasks

bank_reconciliation_task = tasks.bank_reconciliation_task(bank_reconciliation_agent,1111)
transaction_categorization_task = tasks.transaction_categorization_task(transaction_categorization_agent,2222)
general_ledger_entry_task = tasks.general_ledger_entry_task(general_ledger_accountant_agent,3333)
payroll_automation_task = tasks.payroll_automation_task(payroll_automation_agent,4444)
accounts_payable_task = tasks.accounts_payable_task(accounts_payable_agent,5555)
accounts_receivable_task = tasks.accounts_receivable_task(accounts_receivable_agent,6666)
invoice_generation_task = tasks.invoice_generation_task(invoicing_specialist_agent,7777)
late_payment_reminder_task = tasks.late_payment_reminder_task(late_payment_recovery_agent,8888)
expense_reporting_task = tasks.expense_reporting_task(expense_reporting_agent,9999)
reimbursement_processing_task = tasks.reimbursement_processing_task(reimbursement_specialist_agent,1234)
find_initial_information_task = tasks.find_initial_information_task(general_research_agent,0000)


# Define inputs
inputs = {
    "company_name": "XYZ Corporation",
    "location": "New York",
    "bank_statement_path": "Accounting_Inputs/Bank_Statements/bank_statement_feb2025.pdf",
    "transaction_records_path": "Accounting_Inputs/Transactions/transactions_feb2025.json",
    "general_ledger_path": "Accounting_Inputs/General_Ledger/general_ledger_2025.sql",
    "payroll_data_path": "Accounting_Inputs/Payroll_Data/payroll_feb2025.xlsx",
    "tax_deductions_path": "Accounting_Inputs/Payroll_Data/tax_deductions.json",
    "vendor_invoices_path": "Accounting_Inputs/Accounts_Payable/vendor_invoices_feb2025.pdf",
    "customer_invoices_path": "Accounting_Inputs/Accounts_Receivable/customer_invoices_feb2025.csv",
    "expense_reports_path": "Accounting_Inputs/Expense_Reports/employee_expenses_feb2025.xlsx",
    "reimbursement_claims_path": "Accounting_Inputs/Reimbursement_Claims/reimbursement_claims_feb2025.csv",
    "tax_regulations_path": "Accounting_Inputs/Compliance_Documents/tax_regulations_2025.pdf",
    "expense_policy_path": "Accounting_Inputs/Compliance_Documents/company_expense_policy.docx",
    "payment_reminder_schedule_path": "Accounting_Inputs/Automation_Settings/payment_reminder_schedule.json",
    "approval_thresholds_path": "Accounting_Inputs/Automation_Settings/approval_thresholds.json"
}

process_pending_tasks_task = Task(
    description=(
    """
    Take the task provided by the user (`{human_task}`) and determine which agent is best suited to execute it based on the agent's role and capabilities.

    Steps to follow:
    1. **Analyze the Task**: Carefully read and understand the task provided by the user. Identify the key requirements and objectives of the task.
    2. **Match Task to Agent**: Review the roles and capabilities of all available agents. Match the task to the most appropriate agent based on their expertise and tools.
    3. **Delegate the Task**: If a suitable agent is found, delegate the task to that agent and ensure they execute it properly. Provide the agent with all necessary information and context.
    4. **Handle Unmatched Tasks**: If no suitable agent is available to handle the task, inform the user that the task cannot be executed and provide a reason why.
    5. **Monitor Progress**: Continuously monitor the progress of the task. If the task fails or encounters issues, update the task status accordingly and inform the user.
    6. **Ensure Completion**: Once the task is completed, verify that the output meets the user's expectations and update the task status to "COMPLETED".

    Ensure that all tasks are executed efficiently and that the user is kept informed of the progress and any issues that arise.
    """
    ),
    expected_output="""
    The task provided by the user should be executed by the appropriate agent, and the results should be returned to the user.
    If the task cannot be executed, the user should be informed with a clear explanation.
    The task status should be updated dynamically based on the progress and outcome of the task.
    """,

)  



# Crew setup for sequential processing
crew = Crew(
    agents=[
        bank_reconciliation_agent,
        transaction_categorization_agent,
        general_ledger_accountant_agent,
        payroll_automation_agent,
        accounts_payable_agent,
        accounts_receivable_agent,
        invoicing_specialist_agent,
        late_payment_recovery_agent,
        expense_reporting_agent,
        reimbursement_specialist_agent,
        general_research_agent,
        task_manager_agent

    ],
    tasks=[
        bank_reconciliation_task,
        transaction_categorization_task,
        general_ledger_entry_task,
        payroll_automation_task,
        accounts_payable_task,
        accounts_receivable_task,
        invoice_generation_task,
        late_payment_reminder_task,
        expense_reporting_task,
        reimbursement_processing_task,
        find_initial_information_task,
      
    ],
    process=Process.sequential
)

# Execute crew
result = crew.kickoff()
print(result)



# Crew setup for hierarchical human task management
human_task_crew = Crew(
    agents=[
        bank_reconciliation_agent,
        transaction_categorization_agent,
        general_ledger_accountant_agent,
        payroll_automation_agent,
        accounts_payable_agent,
        accounts_receivable_agent,
        invoicing_specialist_agent,
        late_payment_recovery_agent,
        expense_reporting_agent,
        reimbursement_specialist_agent,
        general_research_agent,
        task_manager_agent
    ],
    tasks=[process_pending_tasks_task],
    process=Process.hierarchical,
    manager_llm=manager_llm,
    verbose=True,
    manager_agent=agents.task_manager_agent()
)


human_inputs = {
    "human_task": "Generate a compliance summary for the latest tax regulations."
}

human_result = human_task_crew.kickoff()
print(human_result)
