from crewai import Agent, Crew, Process, Task
from crewai_tools import SerperDevTool
from dotenv import load_dotenv

load_dotenv()

# Define the Agent properly
def email_template_creator() -> Agent:
    return Agent(
        role="Email Template Creator",
        goal="Develop engaging and versatile email templates.",
        verbose=True,
        tools=[SerperDevTool()],
        backstory=(
            "An email marketing expert who understands the nuances of tone, personalization, and structure to capture attention and drive responses."
        ),
        memory=True
    )

# Define the Task properly
def email_template_creator_task(agent: Agent) -> Task:
    return Task(
        description=
        """
        - Use the SerperDevTool to search the internet about email templates.
        - Create customizable cold email templates for "{topic}" tailored to specific sales scenarios using the EmailTemplateCreator Tool.
        - Each template should include a subject line suggestion, a compelling call to action, and placeholders for personalization.

        """,
        expected_output=
        """
        Three well-structured email templates for "{topic}" with placeholders for personalization, subject line recommendations, and calls to action.
        """,
        agent=agent 
    )

# Define the Crew properly
def create_crew() -> Crew:
    """Creates the Crew with the agent and task"""
    agent = email_template_creator()
    task = email_template_creator_task(agent)

    return Crew(
        agents=[agent],   
        tasks=[task],    
        process=Process.sequential,
        verbose=True,
    )

# Define inputs
inputs = {"topic":"""Write a high-converting email for our Black Friday sale with a 50% discount offer."""}

# Execute Crew
result = create_crew().kickoff(inputs=inputs)
print(result)
