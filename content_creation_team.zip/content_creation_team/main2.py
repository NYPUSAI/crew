#!/usr/bin/env python
import sys
import warnings

from manager import ContentCreationTeam


import re
from pymongo import MongoClient

client = MongoClient("mongodb+srv://alimirsa123:a5VtspGwzNRv3m7b@cluster0.3wmvf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")  # Replace with your MongoDB connection string
db = client["tfo"]  # MongoDB database
chat_collection = db["chat"]  # MongoDB collection for chat messages

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")


def run():
    id = 1017
    
    while True:
        message = input("Please write your question (or type 'exit' to stop): ")
        
        if message.lower() == "exit":
            print("Exiting the chat.")
            break  # Exit the loop
        
        messages = list(chat_collection.find({"chat_message_id": str(id)}))
        
        message_dict = {"user": [], "AI": []}
        
        for msg in messages:
            try:
                msg["_id"] = str(msg["_id"])  # Convert ObjectId to string
                message_dict[msg["user"]].append(msg["message"])  # Append message
            except KeyError:
                print(messages)

        last_messages = messages[-2:]  # Get the last two messages
        last_message_dict = {"user": [], "AI": []}
        for msg in last_messages:
            try:
                msg["_id"] = str(msg["_id"])  # Convert ObjectId to string
                last_message_dict[msg["user"]].append(msg["message"])
            except KeyError:
                print(last_messages)

    
        message_document = {
            "chat_message_id": str(id),
            "message": str(message),
            "user": "user",
            "Type": "text",
        }
        chat_collection.insert_one(message_document)

        inputs = {
            'product_description': '',
            'brand_tone': '',
            'target_audience': '',
            'distribution_format': '',
            'human_task': message,
            "context": message_dict,
            "last_conversation": last_message_dict
        }

        result = ContentCreationTeam().crew().kickoff(inputs=inputs)

        message_document = {
            "chat_message_id": str(id),
            "message": str(result),
            "user": "AI",
            "Type": "text",
        }
        chat_collection.insert_one(message_document)
        
        print("AI Response:")
        print(str(result))

run()
