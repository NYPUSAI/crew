from crewai import Agent, Crew, Process, Task
from crewai_tools import SerperDevTool
from dotenv import load_dotenv

load_dotenv()

# Define the Agent properly
def product_description_writer() -> Agent:
    return Agent(
        role="Product Description Writer",
        goal="Craft compelling product descriptions tailored to specific customer needs.",
        verbose=True,
        tools=[SerperDevTool()],
        backstory=(
            "A wordsmith with an innate ability to distill complex information into engaging narratives that resonate with diverse audiences."
        ),
        memory=True
    )

# Define the Task properly
def product_description_writer_task(agent: Agent) -> Task:
    return Task(
        description=
        """
         Use the SerperDevTool to search for inspiration.
        - Write five product descriptions for "{topic}" that effectively highlight customer-centric features and address key pain points.
        """,
        expected_output=
        """
        A set of five compelling product descriptions for {topic}.
        """,
        agent=agent 
    )

# Define the Crew properly
def create_crew() -> Crew:
    """Creates the Crew with the agent and task"""
    agent = product_description_writer()
    task = product_description_writer_task(agent)

    return Crew(
        agents=[agent],   
        tasks=[task],    
        process=Process.sequential,
        verbose=True,
    )

# Define inputs
inputs = {"topic":"Write an engaging product description for a smartwatch with health-tracking features."}

# Execute Crew
result = create_crew().kickoff(inputs=inputs)
print(result)
