from crewai import Agent, Crew, Process, Task
from crewai_tools import SerperDevTool
from dotenv import load_dotenv

load_dotenv()

# Define the Agent properly
def presentation_designer() -> Agent:
    return Agent(
        role="Presesntation Designer",
        goal="Develop captivating PowerPoint decks for sales presentations.",
        verbose=True,
        tools=[SerperDevTool()],
        backstory=(
            "A visual storyteller who thrives in structuring information into compelling narratives through impactful slides."
        ),
        memory=True
    )

# Define the Task properly
def presentation_designer_task(agent: Agent) -> Task:
    return Task(
        description=
        """
        - Design a ten-slide PowerPoint deck that effectively showcases {topic} key features, benefits, and customer success stories.
        - Ensure the deck follows a professional, visually appealing format with structured slides (title, bullet points, images, testimonials).
        """,
        expected_output=
        """
        A well-structured PowerPoint deck for {topic} with ten slides, highlighting its unique selling points (USPs), benefits, and customer testimonials.
        """,
        agent=agent 
    )

# Define the Crew properly
def create_crew() -> Crew:
    """Creates the Crew with the agent and task"""
    agent = presentation_designer()
    task = presentation_designer_task(agent)

    return Crew(
        agents=[agent],   
        tasks=[task],    
        process=Process.sequential,
        verbose=True,
    )

# Define inputs
inputs = {"topic":"Design a sales deck for our AI marketing tool, including case studies and ROI benefits"}

# Execute Crew
result = create_crew().kickoff(inputs=inputs)
print(result)
