from crewai import Agent, Crew, Process, Task
from crewai_tools import SerperDevTool
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
import os

# Load environment variables (including the OpenAI API key)
load_dotenv()

# Initialize global variable for brochure content
brochure_content = ""

# Define the Agent with memory
def sales_brochure_specialist() -> Agent:
    openai_api_key = os.getenv("OPENAI_API_KEY")
    if not openai_api_key:
        raise ValueError("OPENAI_API_KEY environment variable is not set.")

    llm = ChatOpenAI(
        model="gpt-3.5-turbo",
        temperature=0.7,
        max_tokens=1000,
        api_key=openai_api_key
    )

    return Agent(
        role="Sales Brochure Specialist",
        goal="Create and refine engaging sales brochures based on user feedback.",
        verbose=True,
        tools=[SerperDevTool()],
        memory=True,  # Enables iterative improvements
        llm=llm,
        backstory=(
            "You are a skilled marketing specialist with expertise in designing and refining sales brochures. "
            "You listen carefully to user feedback and iteratively improve the content while ensuring it remains "
            "clear, persuasive, and engaging."
        )
    )

# Define the Task to allow continuous refinement
def sales_brochure_specialist_task(agent: Agent, user_input: str, previous_content: str) -> Task:
    return Task(
        description=(
            f"Refine the following sales brochure based on the user's new feedback:\n\n"
            f"Previous Brochure Draft:\n{previous_content}\n\n"
            f"User Feedback:\n{user_input}\n\n"
            f"Ensure that the updated brochure maintains clarity, impact, and professionalism."
        ),
        expected_output="An updated version of the sales brochure incorporating user feedback.",
        agent=agent
    )

# Define the Crew setup
def create_crew(user_input: str, previous_content: str) -> Crew:
    agent = sales_brochure_specialist()
    task = sales_brochure_specialist_task(agent, user_input, previous_content)
    return Crew(
        agents=[agent],   
        tasks=[task],    
        process=Process.sequential,
        verbose=True,
    )

# Chat loop with iterative brochure refinement
def run_chatbot():
    global brochure_content  # Keep track of the evolving brochure content

    print("Welcome to the Sales Brochure Design Assistant!")
    print("Type 'exit' to end the conversation.\n")

    while True:
        user_input = input("You: ")

        if user_input.lower() in ["exit", "quit"]:
            print("Goodbye! Thank you for using the Sales Brochure Design Assistant.")
            break

        try:
            # Create and execute the crew with the latest brochure content
            crew = create_crew(user_input, brochure_content)
            result = crew.kickoff(inputs={})

            # Update the brochure content with the refined version
            brochure_content = result

            # Print the refined output
            print(f"\n🔹 Updated Brochure:\n{result}\n")

        except Exception as e:
            print(f"An error occurred: {e}")

# Run the chatbot
if __name__ == "__main__":
    run_chatbot()
