from crewai import Agent, Crew, Process, Task
from crewai_tools import SerperDevTool
from dotenv import load_dotenv

load_dotenv()

# Define the Agent properly
def email_template_creator() -> Agent:
    return Agent(
        role="Social Media Content Creator",
        goal="Craft engaging LinkedIn posts for sales outreach.",
        verbose=True,
        tools=[SerperDevTool()],
        backstory=(
            "A creative social media enthusiast with a proven track record of crafting posts that generate engagement and drive outreach success."
        ),
        memory=True
    )

# Define the Task properly
def email_template_creator_task(agent: Agent) -> Task:
    return Task(
        description=
        """
        - Use the SerperDevTool to search for inspiration.
        - Develop five engaging LinkedIn posts about {topic} and highlight key benefits and success stories.
        - Each post should include a compelling caption, relevant hashtags, and a call to action.
        """,
        expected_output=
        """
        Five well-structured LinkedIn posts for {topic}, optimized for engagement, with relevant hashtags and clear calls to action.
        """,
        agent=agent 
    )

# Define the Crew properly
def create_crew() -> Crew:
    """Creates the Crew with the agent and task"""
    agent = email_template_creator()
    task = email_template_creator_task(agent)

    return Crew(
        agents=[agent],   
        tasks=[task],    
        process=Process.sequential,
        verbose=True,
    )

# Define inputs
inputs = {"topic":"""Write a high-converting email for our Black Friday sale with a 50% discount offer."""}

# Execute Crew
result = create_crew().kickoff(inputs=inputs)
print(result)
