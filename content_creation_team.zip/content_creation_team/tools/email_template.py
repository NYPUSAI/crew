from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field


class EmailTemplateCreatorInput(BaseModel):
    """Input schema for EmailTemplateCreator."""
    sender_name: str = Field(..., description="Name of the sender.")
    company_name: str = Field(..., description="Company name for branding.")
    lead_generation_offer: str = Field(..., description="Brief description of the lead generation offer or value proposition.")
    follow_up_context: str = Field(..., description="Context for follow-up (e.g., previous interaction, missed response).")
    re_engagement_reason: str = Field(..., description="Reason for re-engagement (e.g., new features, special offer).")


class EmailTemplateCreatorTool(BaseTool):
    name: str = "Email Template Creator"
    description: str = (
        "Generates three customizable cold email templates for sales scenarios: lead generation, follow-ups, and re-engagement. "
        "Each email includes a subject line, a compelling call to action, and placeholders for personalization."
    )
    args_schema: Type[BaseModel] = EmailTemplateCreatorInput

    def _run(self, sender_name: str, company_name: str, lead_generation_offer: str, follow_up_context: str, re_engagement_reason: str) -> str:
        email_templates = []

        # Lead Generation Email Template
        lead_email = f"""
        **Subject:** Unlock Exclusive Benefits with {company_name}  
        
        Hi {{first_name}},  

        I hope you're doing well! I wanted to introduce you to {company_name} and share how we can help {lead_generation_offer}.  

        If you're interested, I'd love to set up a quick call to discuss how this can benefit you. Let me know a time that works for you!  

        Looking forward to your thoughts.  

        Best,  
        {sender_name}  
        """

        # Follow-Up Email Template
        follow_up_email = f"""
        **Subject:** Following Up on Our Last Conversation  

        Hi {{first_name}},  

        I wanted to follow up regarding {follow_up_context}. I know things get busy, so I wanted to check if you had any questions or if now is a better time to connect.  

        Let me know if you're available for a quick call this week. Looking forward to hearing your thoughts!  

        Best,  
        {sender_name}  
        """

        # Re-Engagement Email Template
        re_engagement_email = f"""
        **Subject:** Exciting Updates from {company_name}!  

        Hi {{first_name}},  

        It’s been a while since we last connected, and I wanted to reach out because {re_engagement_reason}.  

        We’d love to hear your thoughts and explore how we can add value to your business. Let’s reconnect—how about a quick call next week?  

        Looking forward to catching up!  

        Best,  
        {sender_name}  
        """

        email_templates.extend([lead_email, follow_up_email, re_engagement_email])

        return "Email templates successfully created:\n\n" + "\n\n".join(email_templates)
