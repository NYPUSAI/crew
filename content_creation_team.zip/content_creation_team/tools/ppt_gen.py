from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field
from pptx import Presentation
from pptx.util import Inches


class PresentationDesignerInput(BaseModel):
    """Input schema for PresentationDesigner."""
    product_name: str = Field(..., description="Name of the product being presented.")
    key_features: list[str] = Field(..., description="List of key features of the product.")
    benefits: list[str] = Field(..., description="List of benefits for the customers.")
    testimonials: list[str] = Field(..., description="Customer testimonials to include in the slides.")
    output_file: str = Field(..., description="Output file name for the presentation (e.g., 'presentation.pptx').")


class PresentationDesignerTool(BaseTool):
    name: str = "Presentation Designer"
    description: str = (
        "Generates a 10-slide PowerPoint deck showcasing the product’s key features, benefits, and customer success stories. "
        "Ensures a professional and visually appealing format."
    )
    args_schema: Type[BaseModel] = PresentationDesignerInput

    def _run(self, product_name: str, key_features: list[str], benefits: list[str], testimonials: list[str], output_file: str) -> str:
        # Create a PowerPoint presentation
        prs = Presentation()

        # Title Slide
        slide_layout = prs.slide_layouts[0]
        slide = prs.slides.add_slide(slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        title.text = f"Introducing {product_name}"
        subtitle.text = "A Presentation on Key Features, Benefits, and Success Stories"

        # Key Features Slide
        slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(slide_layout)
        title = slide.shapes.title
        content = slide.placeholders[1]
        title.text = "Key Features"
        content.text = "\n".join([f"- {feature}" for feature in key_features])

        # Benefits Slide
        slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(slide_layout)
        title = slide.shapes.title
        content = slide.placeholders[1]
        title.text = "Benefits"
        content.text = "\n".join([f"- {benefit}" for benefit in benefits])

        # Customer Testimonials Slide
        slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(slide_layout)
        title = slide.shapes.title
        content = slide.placeholders[1]
        title.text = "What Customers Are Saying"
        content.text = "\n".join([f'"{testimonial}"' for testimonial in testimonials])

        # Thank You Slide
        slide_layout = prs.slide_layouts[0]
        slide = prs.slides.add_slide(slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        title.text = "Thank You!"
        subtitle.text = f"Learn more about {product_name} today."

        # Save the presentation
        prs.save(output_file)

        return f"Presentation '{output_file}' has been successfully created."
