#!/usr/bin/env python
import sys
import warnings

from crew import ContentCreationTeam

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

def run():
    """
    Run the crew.
    """
    inputs = inputs = {
        'topic': "Samsung Galaxy S24"
    }
    ContentCreationTeam().crew().kickoff(inputs=inputs)

run()
 