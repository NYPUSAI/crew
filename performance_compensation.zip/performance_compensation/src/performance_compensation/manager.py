from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from dotenv import load_dotenv
from typing import Optional
from crewai_tools import CSVSearchTool,FileReadTool,DOCXSearchTool,PDFSearchTool,JSONSearchTool,SerperDevTool,YoutubeVideoSearchTool
from pydantic import BaseModel,Field

load_dotenv()

class Performance_Comp(BaseModel):
	goal_setting_specialist_task_status: Optional[str] = Field(None,description="Status of theGoal Setting specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	performance_review_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Performance review coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	feedback_analyst_task_status:  Optional[str] = Field(None,description="Status of the Feeback analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	performance_analyst_task_status:  Optional[str] = Field(None,description="Status of the Performance Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	skill_development_advisor_task_status:  Optional[str] = Field(None,description="Status of the Skill Development advisor task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	peer_review_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Peer Review Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	probation_review_specialist_task_status:  Optional[str] = Field(None,description="Status of the Probation Review Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	compensation_analyst_task_status:  Optional[str] = Field(None,description="Status of the Compensation Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	promotion_criteria_specialist_task__status:  Optional[str] = Field(None,description="Status of the Promotion Criteria Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	kpi_monitoring_expert_task_status:  Optional[str] = Field(None,description="Status of the KPI monitoring expert task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	payroll_manager_task_status:  Optional[str] = Field(None,description="Status of the Payroll manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	expense_reimburement_officer_task_status:  Optional[str] = Field(None,description="Status of the Expense Reimbursement Officer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	tax_compiance_officer_task_status:  Optional[str] = Field(None,description="Status of the Tax Compliance Officer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	benefit_enrollment_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Benefit Enrollment Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	leave_balance_manager_task_status:  Optional[str] = Field(None,description="Status of the Leave Balance Manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	overtime_tracker_task_status:  Optional[str] = Field(None,description="Status of the Overtime Tracker task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	salary_breakdown_analyst_task_status:  Optional[str] = Field(None,description="Status of the Salary Breakdown analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	compliance_auditor_task_status:  Optional[str] = Field(None,description="Status of the Compliance Auditor task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	bonus_calculation_specialist_task_status:  Optional[str] = Field(None,description="Status of the Bonus Calculation specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	pension_contribution_manager_task_status:  Optional[str] = Field(None,description="Status of the Pension contribution manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")

@CrewBase
class PerformanceCompensation():
	"""PerformanceCompensation crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'


	@agent
	def goal_setting_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['goal_setting_specialist'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def performance_review_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['performance_review_coordinator'],
			verbose=True,
			tools=[JSONSearchTool()]
		)
	
	@agent
	def feedback_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['feedback_analyst'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def performance_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['performance_analyst'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def skill_development_advisor(self) -> Agent:
		return Agent(
			config=self.agents_config['skill_development_advisor'],
			verbose=True,
			tools=[SerperDevTool(),YoutubeVideoSearchTool()]
		)
	
	@agent
	def peer_review_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['peer_review_coordinator'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def probation_review_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['probation_review_specialist'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def compensation_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['compensation_analyst'],
			verbose=True,
			tools=[DOCXSearchTool(),FileReadTool()]
		)
	
	@agent
	def promotion_criteria_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['promotion_criteria_specialist'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def kpi_monitoring_expert(self) -> Agent:
		return Agent(
			config=self.agents_config['kpi_monitoring_expert'],
			verbose=True,
			tools=[JSONSearchTool()]
		)
	
	@agent
	def payroll_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['payroll_manager'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def expense_reimburement_officer(self) -> Agent:
		return Agent(
			config=self.agents_config['expense_reimburement_officer'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def tax_compiance_officer(self) -> Agent:
		return Agent(
			config=self.agents_config['tax_compiance_officer'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def benefit_enrollment_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['benefit_enrollment_coordinator'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def leave_balance_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['leave_balance_manager'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def overtime_tracker(self) -> Agent:
		return Agent(
			config=self.agents_config['overtime_tracker'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def salary_breakdown_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['salary_breakdown_analyst'],
			verbose=True,
			tools=[FileReadTool()]
		)
	
	@agent
	def compliance_auditor(self) -> Agent:
		return Agent(
			config=self.agents_config['compliance_auditor'],
			verbose=True,
			tools=[JSONSearchTool()]
		)
	
	@agent
	def bonus_calculation_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['bonus_calculation_specialist'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def pension_contribution_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['pension_contribution_manager'],
			verbose=True,
			tools=[PDFSearchTool()]
		)
	
	@agent
	def general_researcher(self) -> Agent:
		return Agent(
			config=self.agents_config['general_researcher'],
			verbose=True,
			tools=[]
		)

	@task
	def goal_setting_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['goal_setting_specialist_task'],
		)

	@task
	def performance_review_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['performance_review_coordinator_task'],
		)

	@task
	def feedback_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['feedback_analyst_task'],
		)


	@task
	def performance_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['performance_analyst_task'],
		)

	@task
	def skill_development_advisor_task(self) -> Task:
		return Task(
			config=self.tasks_config['skill_development_advisor_task'],
		)


	@task
	def peer_review_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['peer_review_coordinator_task'],
		)

	@task
	def probation_review_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['probation_review_specialist_task'],
		)

	@task
	def compensation_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['compensation_analyst_task'],
		)

	@task
	def promotion_criteria_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['promotion_criteria_specialist_task'],
		)

	@task
	def kpi_monitoring_expert_task(self) -> Task:
		return Task(
			config=self.tasks_config['kpi_monitoring_expert_task'],
		)

	@task
	def payroll_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['payroll_manager_task'],
		)

	@task
	def expense_reimburement_officer_task(self) -> Task:
		return Task(
			config=self.tasks_config['expense_reimburement_officer_task'],
		)

	@task
	def tax_compiance_officer_task(self) -> Task:
		return Task(
			config=self.tasks_config['tax_compiance_officer_task'],
		)

	@task
	def benefit_enrollment_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['benefit_enrollment_coordinator_task'],
		)

	@task
	def leave_balance_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['leave_balance_manager_task'],
		)

	@task
	def overtime_tracker_task(self) -> Task:
		return Task(
			config=self.tasks_config['overtime_tracker_task'],
		)

	@task
	def salary_breakdown_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['salary_breakdown_analyst_task'],
		)

	@task
	def compliance_auditor_task(self) -> Task:
		return Task(
			config=self.tasks_config['compliance_auditor_task'],
		)

	@task
	def bonus_calculation_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['bonus_calculation_specialist_task'],
		)

	@task
	def pension_contribution_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['pension_contribution_manager_task'],
		)
	@task
	def task_completion_status(self) -> Task:
		return Task(
			config=self.tasks_config['task_completion_status'],
			output_pydantic=Performance_Comp
		)


	@agent
	def manager(self) -> Agent:
		return Agent(
			role="Task Manager",
            goal="Efficiently identify, delegate, and oversee the execution of tasks based on user input, ensuring timely and accurate completion while maintaining clear communication with the user.",
            verbose=True,
            tools=[],
            backstory=(
                """
                You are a highly organized and detail-oriented professional with extensive experience in task management and delegation. 
                Your expertise lies in understanding complex requirements, matching tasks to the right resources, and ensuring seamless execution.
                With a strong focus on efficiency and accountability, you thrive in dynamic environments where multiple tasks need to be managed simultaneously.
                Your ability to communicate clearly and monitor progress ensures that tasks are completed on time and meet the highest standards of quality.
                """
            ),
            allow_delegation=True,
            memory=True
        )
	@task
	def process_pending_tasks_task(self) -> Task:
		return Task(
            description=(
		"""
		Take the task provided by the user (`{human_task}`) and determine which agent is best suited to execute it based on the agent's role and capabilities.

		Steps to follow:
		1. **Analyze the Task**: Carefully read and understand the task provided by the user. Identify the key requirements and objectives of the task.
		2. **Match Task to Agent**: Review the roles and capabilities of all available agents. Match the task to the most appropriate agent based on their expertise and tools.
		3. **Delegate the Task**: If a suitable agent is found, delegate the task to that agent and ensure they execute it properly. Provide the agent with all necessary information and context.
		4. **Handle Unmatched Tasks**: If no suitable agent is available to handle the task, inform the user that the task cannot be executed and provide a reason why.
		5. **Monitor Progress**: Continuously monitor the progress of the task. If the task fails or encounters issues, update the task status accordingly and inform the user.
		6. **Ensure Completion**: Once the task is completed, verify that the output meets the user's expectations and update the task status to "COMPLETED".

		Ensure that all tasks are executed efficiently and that the user is kept informed of the progress and any issues that arise.
		"""
		),
		expected_output="""
		The task provided by the user should be executed by the appropriate agent, and the results obtained by the agent should be shown to the user.
		If the task cannot be executed, the user should be informed with a clear explanation.
		The task status should be updated dynamically based on the progress and outcome of the task.
		""",
        )

	@crew
	def crew(self) -> Crew:
		"""Creates the ProjectPlanner crew"""
		return Crew(
            agents=[self.goal_setting_specialist(),
					self.performance_analyst(),
					self.feedback_analyst(),
					self.performance_analyst(),
                    self.skill_development_advisor(),
                    self.peer_review_coordinator(),
                    self.probation_review_specialist(),
                    self.compensation_analyst(),
                    self.promotion_criteria_specialist(),
                    self.kpi_monitoring_expert(),
                    self.payroll_manager(),
                    self.expense_reimburement_officer(),
                    self.tax_compiance_officer(),
                    self.benefit_enrollment_coordinator(),
                    self.leave_balance_manager(),
                    self.overtime_tracker(),
					self.salary_breakdown_analyst(),
					self.compliance_auditor(),
					self.bonus_calculation_specialist(),
					self.pension_contribution_manager(),
                    self.general_researcher(),],
			tasks=[self.process_pending_tasks_task(),],
			process=Process.hierarchical,
			verbose=True,
			manager_agent=self.manager(),
    )