import sys
import warnings

from manager import PerformanceCompensation

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

# This main file is intended to be a way for you to run your
# crew locally, so refrain from adding unnecessary logic into this file.
# Replace with inputs you want to test with, it will automatically
# interpolate any tasks and agents information

def run():
    """
    Run the crew.
    """
    inputs = {
        'human_task': 'Can you help me set some new goals for the new quarter for my emplyees to foster teamwork'
    }
    PerformanceCompensation().crew().kickoff(inputs=inputs)

run()