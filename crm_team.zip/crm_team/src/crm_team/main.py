#!/usr/bin/env python
import sys
import warnings
from dotenv import load_dotenv

from crew import CrmTeam

# Load environment variables
load_dotenv()

# Suppress specific warnings (if pysbd is used)
warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

# Prompt user for key CRM-related inputs
company_product = "Apple - iPhone 15"
customer_type = "Retail Consumers"
interaction_channel = "Social Media"
feedback_source = "Google Reviews and Twitter Mentions"
purchase_history_depth = "Last 12 months"


# Format the topic as a clear sentence
topic = (f"Analyze customer engagement and CRM strategies for {company_product}, "
         f"targeting {customer_type}. Focus on interactions through {interaction_channel}, "
         f"while evaluating customer feedback from {feedback_source}. "
         f"Additionally, assess purchase behaviors based on {purchase_history_depth} of sales data.")

def run():
    """
    Run the CRM team workflow with structured inputs.
    """
    inputs = {
        "topic": topic,
    }
    
    # Execute the CRM workflow with structured input
    CrmTeam().crew().kickoff(inputs=inputs)

if __name__ == "__main__":
    run()
