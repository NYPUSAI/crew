```python
import matplotlib.pyplot as plt

# Sample data
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May']
sales = [10000, 15000, 12000, 18000, 20000]

plt.figure(figsize=(10, 6))
plt.plot(months, sales, marker='o')
plt.title('Company Sales Over Months')
plt.xlabel('Months')
plt.ylabel('Sales')
plt.grid(True)
plt.savefig('visualization.png')
plt.show()
```