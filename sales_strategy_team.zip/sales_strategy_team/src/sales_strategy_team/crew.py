from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import SerperDevTool
#import sales_schema
from dotenv import load_dotenv

load_dotenv()

@CrewBase
class SalesStrategyTeam():
	"""SalesStrategyTeam crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'


	@agent
	def market_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['market_analyst'],
			verbose=True,
			tools=[SerperDevTool()],
		)
	

	@agent
	def swot_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['swot_analyst'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def competitor_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['competitor_analyst'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def pricing_strategist(self) -> Agent:
		return Agent(
			config=self.agents_config['pricing_strategist'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def sales_pitch_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['sales_pitch_specialist'],
			verbose=True,
			tools=[SerperDevTool()]
		)


	@task
	def market_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['market_analyst_task'],
			#output_json=sales_schema.MarketAnalystOutput
		)
	

	@task
	def swot_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['swot_analyst_task'],
			#output_json=sales_schema.SWOTAnalysisOutput
		)
	
	@task
	def competitor_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['competitor_analyst_task'],
			#output_json=sales_schema.CompetitorAnalysisOutput
		)

	@task
	def pricing_strategist_task(self) -> Task:
		return Task(
			config=self.tasks_config['pricing_strategist_task'],
			#output_json=sales_schema.PricingModelOutput
		)
	
	@task
	def sales_pitch_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['sales_pitch_specialist_task'],
			#output_json=sales_schema.SalesPitchOutput
		)

	@crew
	def crew(self) -> Crew:
		"""Creates the SalesStrategyTeam crew"""

		return Crew(
			agents=self.agents, # Automatically created by the @agent decorator
			tasks=self.tasks, # Automatically created by the @task decorator
			process=Process.sequential,
			verbose=True,
			chat_llm="gpt-3.5-turbo"
		)
