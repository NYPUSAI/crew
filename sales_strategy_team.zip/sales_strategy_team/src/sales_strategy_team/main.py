#!/usr/bin/env python
import sys
import warnings
from crew import SalesStrategyTeam

# Suppress SyntaxWarnings related to pysbd (only if pysbd is used)
warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

def run():
    # Define structured input variables
    industry_sector = "Samsung Galaxy S24 Smartphone Industry"
    target_market = "tech enthusiasts and professionals"
    timeframe = "the last 12 months"
    data_source = "market research reports, customer reviews, and sales data"

    # Format the topic as a clear sentence
    topic = (f"Analyze the {industry_sector} with a focus on {target_market} "
             f"over {timeframe}, using data from {data_source}.")

    inputs = {"topic": topic}

    # Ensure SalesStrategyTeam initializes correctly
    crew = SalesStrategyTeam().crew()
    
    # Execute the AI workflow with structured input
    crew.kickoff(inputs=inputs)

if __name__ == "__main__":
    run()
