#!/usr/bin/env python
import sys
import warnings

from datetime import datetime

from crew import SeoSemCrew

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

def run():
    """
    Run the crew.
    """
    website_name = "https://www.shopclues.com/"
    competitors = "https://www.amazon.in/, https://www.flipkart.com/, https://www.myntra.com/"
    target_audience = "Budget-Conscious Shoppers"
    ad_budget = "Monthly ad budget of $5,000 – $15,000"

    # Format the topic variable as a detailed sentence
    topic = (f"Develop and optimize SEO and SEM strategies for {website_name}, "
             f"targeting {target_audience}. Conduct competitive analysis against "
             f"{competitors} and create ad campaigns within an {ad_budget}.")

    # Define inputs for the CrewAI task
    inputs = {
        'topic': topic,
    }

    try:
        SeoSemCrew().crew().kickoff(inputs=inputs)
    except Exception as e:
        raise Exception(f"An error occurred while running the crew: {e}")


run()
