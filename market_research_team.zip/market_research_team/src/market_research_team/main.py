#!/usr/bin/env python
import sys
import warnings
from crew import MarketResearchTeam

# Suppress SyntaxWarnings related to pysbd (only if pysbd is used)
warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

def run():
    # Define structured input variables
    geographic_focus = "North America and Europe"
    review_source = "Google Reviews, Trustpilot, and Social Media Mentions"
    target_audience = "Tech Enthusiasts and Business Professionals"
    timeframe = "Last 12 months"

    # Format the topic as a clear sentence
    topic = (f"Conduct a detailed market and lead analysis focusing on businesses in {geographic_focus}. "
             f"Additionally, review customer feedback from {review_source} to understand {target_audience} "
             f"preferences over the {timeframe}.")

    # Define inputs to be used by CrewAI tasks
    inputs = {
        "topic": topic,
    }

    # Ensure LeadGenerationTeam initializes correctly
    crew = MarketResearchTeam().crew()
    
    # Execute the AI workflow with structured input
    crew.kickoff(inputs=inputs)

if __name__ == "__main__":
    run()
