import os
import yaml
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get the absolute path of the current script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # This is `src/lead_generation_team/`
CONFIG_DIR = os.path.abspath(os.path.join(BASE_DIR, "config"))  # ✅ Corrected path

# Function to load YAML files safely
def load_yaml(file_name):
    """Loads a YAML file from the config directory."""
    file_path = os.path.join(CONFIG_DIR, file_name)

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"⚠️ ERROR: Config file not found -> {file_path}")

    with open(file_path, "r") as file:
        return yaml.safe_load(file) or {}

# Load configurations
AGENTS_CONFIG = load_yaml("agents.yaml")
TASKS_CONFIG = load_yaml("tasks.yaml")

# Debugging: Print file paths
print(f"✅ Loaded Agents Config from: {os.path.join(CONFIG_DIR, 'agents.yaml')}")
print(f"✅ Loaded Tasks Config from: {os.path.join(CONFIG_DIR, 'tasks.yaml')}")
