#!/usr/bin/env python
import sys
import warnings
from flows.lead_generation_flow import flow  # Import the Flow

# Suppress unnecessary warnings
warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

def run():
    # Define structured input variables
    target_industry = "Smartphone and Consumer Electronics"
    company_size_range = "Mid-sized (50-500 employees)"
    geographic_focus = "North America and Europe"
    lead_source_channels = "LinkedIn, Crunchbase, and industry reports"

    # Format the topic as a clear sentence
    topic = (
        f"Conduct a detailed market and lead analysis for the {target_industry} sector, "
        f"focusing on {company_size_range} businesses in {geographic_focus}. "
        f"Use data from {lead_source_channels} to assess market trends, identify leads, "
        f"analyze competitors, and develop strategic insights."
    )

    # ✅ Make sure 'inputs' matches the Flow's expected parameters
    inputs = {"topic": topic}  

    # Execute the Flow with structured input
    print("🚀 Starting Lead Generation Flow...\n")
    result = flow.kickoff(inputs=inputs)  # ✅ Pass 'inputs' correctly

    # Print the final result
    print("\n🎯 Final Output:\n", result)

if __name__ == "__main__":
    run()
