from crewai.flow.flow import Flow, listen, start
from crewai import Agent, Task
from crewai_tools import SerperDevTool
from dotenv import load_dotenv
import yaml
import os

# Load environment variables
load_dotenv()

# Get the absolute path of the config directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # This is `flows/`
CONFIG_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "config"))  # ✅ Corrected path

# Function to load YAML files safely
def load_yaml(file_name):
    """Loads a YAML file from the config directory."""
    file_path = os.path.join(CONFIG_DIR, file_name)

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"⚠️ ERROR: Config file not found -> {file_path}")

    with open(file_path, "r") as file:
        return yaml.safe_load(file) or {}

# Load configurations
AGENTS_CONFIG = load_yaml("agents.yaml")
TASKS_CONFIG = load_yaml("tasks.yaml")

# Debugging: Print file paths
print(f"✅ Loaded Agents Config from: {os.path.join(CONFIG_DIR, 'agents.yaml')}")
print(f"✅ Loaded Tasks Config from: {os.path.join(CONFIG_DIR, 'tasks.yaml')}")

# Initialize tools
search_tool = SerperDevTool()

class LeadGenerationFlow(Flow):
    """Flow-based implementation of the Lead Generation process"""

    model = "gpt-3.5-turbo"

    @start()
    def identify_leads(self, topic):
        print(f"🚀 Step 1: Identifying potential leads for {topic}...")

        lead_identifier = Agent(
            **AGENTS_CONFIG["lead_identifier"],
            tools=[search_tool],
            verbose=True
        )

        lead_identifier_task = Task(
            **TASKS_CONFIG["lead_identifier_task"],
            tools=[search_tool]
        )

        response = lead_identifier_task.run(inputs={"topic": topic})
        print(f"✅ Identified Leads:\n{response}")

        return response

flow = LeadGenerationFlow()
