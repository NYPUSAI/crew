#!/usr/bin/env python
import sys
import warnings

from crew import CommsStakeholder

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

def run():
    """
    Run the crew.
    """
    # inputs = {
    #     'topic': 'AI LLMs'
    # }
    CommsStakeholder().crew().kickoff()


run()