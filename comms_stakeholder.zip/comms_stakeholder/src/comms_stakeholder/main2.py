#!/usr/bin/env python
import sys
import warnings

from manager import CommsStakeholder

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

def run():
    """
    Run the crew.
    """
    inputs = {
        'human_task': 'Can you help schedule a meeting for March 1st 2025 at 10 AM.'
    }
    CommsStakeholder().crew().kickoff(inputs=inputs)


run()