from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import SerperDevTool,TXTSearchTool,DOCXSearchTool
from dotenv import load_dotenv
from pydantic import BaseModel,Field
from typing import Optional

load_dotenv()


class Communication_Stakeholder(BaseModel):
		communication_manager_task_status: Optional[str] = Field(None,description="Status of the Communication Manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")
		stake_engagement_lead_task_status:  Optional[str] = Field(None,description="Status of the Stake Engaement Lead task(eg: COMPLETED, IN_PROGRESS, FAILED)")
		meeting_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Meeting Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
		project_reporter_task_status:  Optional[str] = Field(None,description="Status of the Project Reporter task(eg: COMPLETED, IN_PROGRESS, FAILED)")
		team_collaborator_task_status:  Optional[str] = Field(None,description="Status of the Team Collaborator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
		conflict_resolver_task_status:  Optional[str] = Field(None,description="Status of the Conflict Resolver task(eg: COMPLETED, IN_PROGRESS, FAILED)")

@CrewBase
class CommsStakeholder():
	"""CommsStakeholder crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'

	@agent
	def communication_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['communication_manager'],
			verbose=True
		)
	
	@agent
	def stake_engagement_lead(self) -> Agent:
		return Agent(
			config=self.agents_config['stake_engagement_lead'],
			verbose=True
		)
	
	@agent
	def meeting_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['meeting_coordinator'],
			verbose=True
		)
	
	@agent
	def project_reporter(self) -> Agent:
		return Agent(
			config=self.agents_config['project_reporter'],
			verbose=True
		)
	
	@agent
	def team_collaborator(self) -> Agent:
		return Agent(
			config=self.agents_config['team_collaborator'],
			verbose=True
		)
	
	@agent
	def conflict_resolver(self) -> Agent:
		return Agent(
			config=self.agents_config['conflict_resolver'],
			verbose=True
		)
	
	@agent
	def general_researcher(self) -> Agent:
		return Agent(
			config=self.agents_config['general_researcher'],
			verbose=True,
			tools=[]
		)


	@task
	def communication_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['communication_manager_task'],
		)
	
	@task
	def stake_engagement_lead_task(self) -> Task:
		return Task(
			config=self.tasks_config['stake_engagement_lead_task'],
		)
	
	@task
	def meeting_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['meeting_coordinator_task'],
		)
	
	@task
	def project_reporter_task(self) -> Task:
		return Task(
			config=self.tasks_config['project_reporter_task'],
		)
	
	@task
	def team_collaborator_task(self) -> Task:
		return Task(
			config=self.tasks_config['team_collaborator_task'],
		)
	
	@task
	def conflict_resolver_task(self) -> Task:
		return Task(
			config=self.tasks_config['conflict_resolver_task'],
		)
	
	@task
	def task_completion_status(self) -> Task:
		return Task(
			config=self.tasks_config['task_completion_status'],
			output_pydantic=Communication_Stakeholder
		)


	@crew
	def crew(self) -> Crew:
		"""Creates the CommsStakeholder crew"""
		return Crew(
			agents=self.agents, # Automatically created by the @agent decorator
			tasks=self.tasks, # Automatically created by the @task decorator
			process=Process.sequential,
			verbose=True,
		)
