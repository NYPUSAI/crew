from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from dotenv import load_dotenv
from typing import Optional
from crewai_tools import CSVSearchTool,FileReadTool,DOCXSearchTool,PDFSearchTool,JSONSearchTool,SerperDevTool,YoutubeVideoSearchTool
from pydantic import BaseModel,Field

load_dotenv()
class Compliance_pol(BaseModel):
	compliance_officer_task_status: Optional[str] = Field(None,description="Status of the Compliance Officer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	legal_compliance_analyst_task_status:  Optional[str] = Field(None,description="Status of the Legal Compliance Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	data_protection_officer_task_status:  Optional[str] = Field(None,description="Status of the Data Protection Officer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	compliance_auditor_task_status:  Optional[str] = Field(None,description="Status of the Compliance Auditor task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	employee_support_specilaist_task_status:  Optional[str] = Field(None,description="Status of the Employee Support Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	di_analyst_task_status:  Optional[str] = Field(None,description="Status of the DI Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	workplace_compliance_officer_task_status:  Optional[str] = Field(None,description="Status of the Workplace compliance officer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	safety_compliance_trainer_task_status:  Optional[str] = Field(None,description="Status of the Safety Compliance Trainer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	regulatory_affairs_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Regulatory affairs coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	hr_compliance_specialist_task_status:  Optional[str] = Field(None,description="Status of the HR Compliance Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")

@CrewBase
class CompliancePolicy():
	"""CompliancePolicy crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'

	@agent
	def compliance_officer(self) -> Agent:
		return Agent(
			config=self.agents_config['compliance_officer'],
			verbose=True,
			tools=[PDFSearchTool()]
		)
	
	@agent
	def legal_compliance_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['legal_compliance_analyst'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def data_protection_officer(self) -> Agent:
		return Agent(
			config=self.agents_config['data_protection_officer'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def compliance_auditor(self) -> Agent:
		return Agent(
			config=self.agents_config['compliance_auditor'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def employee_support_specilaist(self) -> Agent:
		return Agent(
			config=self.agents_config['employee_support_specilaist'],
			verbose=True,
			tools=[DOCXSearchTool(),FileReadTool()]
		)
	
	@agent
	def di_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['di_analyst'],
			verbose=True,
			tools=[JSONSearchTool()]
		)
	
	@agent
	def workplace_compliance_officer(self) -> Agent:
		return Agent(
			config=self.agents_config['workplace_compliance_officer'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def safety_compliance_trainer(self) -> Agent:
		return Agent(
			config=self.agents_config['safety_compliance_trainer'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def regulatory_affairs_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['regulatory_affairs_coordinator'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def hr_compliance_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['hr_compliance_specialist'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)

	@agent
	def general_researcher(self) -> Agent:
		return Agent(
			config=self.agents_config['general_researcher'],
			verbose=True,
			tools=[]
		)

	@task
	def compliance_officer_task(self) -> Task:
		return Task(
			config=self.tasks_config['compliance_officer_task'],
		)
	
	@task
	def legal_compliance_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['legal_compliance_analyst_task'],
		)
	
	@task
	def data_protection_officer_task(self) -> Task:
		return Task(
			config=self.tasks_config['data_protection_officer_task'],
		)
	
	@task
	def compliance_auditor_task(self) -> Task:
		return Task(
			config=self.tasks_config['compliance_auditor_task'],
		)
	
	@task
	def employee_support_specilaist_task(self) -> Task:
		return Task(
			config=self.tasks_config['employee_support_specilaist_task'],
		)
	
	@task
	def di_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['di_analyst_task'],
		)
	
	@task
	def workplace_compliance_officer_task(self) -> Task:
		return Task(
			config=self.tasks_config['workplace_compliance_officer_task'],
		)
	
	@task
	def safety_compliance_trainer_task(self) -> Task:
		return Task(
			config=self.tasks_config['safety_compliance_trainer_task'],
		)
	
	@task
	def regulatory_affairs_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['regulatory_affairs_coordinator_task'],
		)
	
	@task
	def hr_compliance_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['hr_compliance_specialist_task'],
		)
	
	@task
	def task_completion_status(self) -> Task:
		return Task(
			config=self.tasks_config['task_completion_status'],
			output_pydantic=Compliance_pol
		)

	@agent
	def manager(self) -> Agent:
		return Agent(
			role="Task Manager",
            goal="Efficiently identify, delegate, and oversee the execution of tasks based on user input, ensuring timely and accurate completion while maintaining clear communication with the user.",
            verbose=True,
            tools=[],
            backstory=(
                """
                You are a highly organized and detail-oriented professional with extensive experience in task management and delegation. 
                Your expertise lies in understanding complex requirements, matching tasks to the right resources, and ensuring seamless execution.
                With a strong focus on efficiency and accountability, you thrive in dynamic environments where multiple tasks need to be managed simultaneously.
                Your ability to communicate clearly and monitor progress ensures that tasks are completed on time and meet the highest standards of quality.
                """
            ),
            allow_delegation=True,
            memory=True
        )
	@task
	def process_pending_tasks_task(self) -> Task:
		return Task(
            description=(
		"""
		Take the task provided by the user (`{human_task}`) and determine which agent is best suited to execute it based on the agent's role and capabilities.

		Steps to follow:
		1. **Analyze the Task**: Carefully read and understand the task provided by the user. Identify the key requirements and objectives of the task.
		2. **Match Task to Agent**: Review the roles and capabilities of all available agents. Match the task to the most appropriate agent based on their expertise and tools.
		3. **Delegate the Task**: If a suitable agent is found, delegate the task to that agent and ensure they execute it properly. Provide the agent with all necessary information and context.
		4. **Handle Unmatched Tasks**: If no suitable agent is available to handle the task, inform the user that the task cannot be executed and provide a reason why.
		5. **Monitor Progress**: Continuously monitor the progress of the task. If the task fails or encounters issues, update the task status accordingly and inform the user.
		6. **Ensure Completion**: Once the task is completed, verify that the output meets the user's expectations and update the task status to "COMPLETED".

		Ensure that all tasks are executed efficiently and that the user is kept informed of the progress and any issues that arise.
		"""
		),
		expected_output="""
		The task provided by the user should be executed by the appropriate agent, and the results obtained by the agent should be shown to the user.
		If the task cannot be executed, the user should be informed with a clear explanation.
		The task status should be updated dynamically based on the progress and outcome of the task.
		""",
        )

	@crew
	def crew(self) -> Crew:
		"""Creates the ProjectPlanner crew"""
		return Crew(
            agents=[self.compliance_officer(),
					self.legal_compliance_analyst(),
					self.data_protection_officer(),
					self.compliance_auditor(),
                    self.employee_support_specilaist(),
                    self.di_analyst(),
                    self.workplace_compliance_officer(),
                    self.safety_compliance_trainer(),
                    self.regulatory_affairs_coordinator(),
                    self.hr_compliance_specialist(),
                    self.general_researcher(),],
			tasks=[self.process_pending_tasks_task(),],
			process=Process.hierarchical,
			verbose=True,
			manager_agent=self.manager(),
    )