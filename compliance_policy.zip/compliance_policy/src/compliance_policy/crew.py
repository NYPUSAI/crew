from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from dotenv import load_dotenv
from typing import Optional
from crewai_tools import CSVSearchTool,FileReadTool,DOCXSearchTool,PDFSearchTool,JSONSearchTool,SerperDevTool,YoutubeVideoSearchTool
from pydantic import BaseModel,Field

load_dotenv()
class Compliance_pol(BaseModel):
	compliance_officer_task_status: Optional[str] = Field(None,description="Status of the Compliance Officer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	legal_compliance_analyst_task_status:  Optional[str] = Field(None,description="Status of the Legal Compliance Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	data_protection_officer_task_status:  Optional[str] = Field(None,description="Status of the Data Protection Officer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	compliance_auditor_task_status:  Optional[str] = Field(None,description="Status of the Compliance Auditor task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	employee_support_specilaist_task_status:  Optional[str] = Field(None,description="Status of the Employee Support Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	di_analyst_task_status:  Optional[str] = Field(None,description="Status of the DI Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	workplace_compliance_officer_task_status:  Optional[str] = Field(None,description="Status of the Workplace compliance officer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	safety_compliance_trainer_task_status:  Optional[str] = Field(None,description="Status of the Safety Compliance Trainer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	regulatory_affairs_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Regulatory affairs coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	hr_compliance_specialist_task_status:  Optional[str] = Field(None,description="Status of the HR Compliance Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")

@CrewBase
class CompliancePolicy():
	"""CompliancePolicy crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'

	@agent
	def compliance_officer(self) -> Agent:
		return Agent(
			config=self.agents_config['compliance_officer'],
			verbose=True,
			tools=[PDFSearchTool()]
		)
	
	@agent
	def legal_compliance_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['legal_compliance_analyst'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def data_protection_officer(self) -> Agent:
		return Agent(
			config=self.agents_config['data_protection_officer'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def compliance_auditor(self) -> Agent:
		return Agent(
			config=self.agents_config['compliance_auditor'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def employee_support_specilaist(self) -> Agent:
		return Agent(
			config=self.agents_config['employee_support_specilaist'],
			verbose=True,
			tools=[DOCXSearchTool(),FileReadTool()]
		)
	
	@agent
	def di_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['di_analyst'],
			verbose=True,
			tools=[JSONSearchTool()]
		)
	
	@agent
	def workplace_compliance_officer(self) -> Agent:
		return Agent(
			config=self.agents_config['workplace_compliance_officer'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def safety_compliance_trainer(self) -> Agent:
		return Agent(
			config=self.agents_config['safety_compliance_trainer'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def regulatory_affairs_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['regulatory_affairs_coordinator'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def hr_compliance_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['hr_compliance_specialist'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)

	@agent
	def general_researcher(self) -> Agent:
		return Agent(
			config=self.agents_config['general_researcher'],
			verbose=True,
			tools=[]
		)

	@task
	def compliance_officer_task(self) -> Task:
		return Task(
			config=self.tasks_config['compliance_officer_task'],
		)
	
	@task
	def legal_compliance_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['legal_compliance_analyst_task'],
		)
	
	@task
	def data_protection_officer_task(self) -> Task:
		return Task(
			config=self.tasks_config['data_protection_officer_task'],
		)
	
	@task
	def compliance_auditor_task(self) -> Task:
		return Task(
			config=self.tasks_config['compliance_auditor_task'],
		)
	
	@task
	def employee_support_specilaist_task(self) -> Task:
		return Task(
			config=self.tasks_config['employee_support_specilaist_task'],
		)
	
	@task
	def di_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['di_analyst_task'],
		)
	
	@task
	def workplace_compliance_officer_task(self) -> Task:
		return Task(
			config=self.tasks_config['workplace_compliance_officer_task'],
		)
	
	@task
	def safety_compliance_trainer_task(self) -> Task:
		return Task(
			config=self.tasks_config['safety_compliance_trainer_task'],
		)
	
	@task
	def regulatory_affairs_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['regulatory_affairs_coordinator_task'],
		)
	
	@task
	def hr_compliance_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['hr_compliance_specialist_task'],
		)
	
	@task
	def task_completion_status(self) -> Task:
		return Task(
			config=self.tasks_config['task_completion_status'],
			output_pydantic=Compliance_pol
		)

	@crew
	def crew(self) -> Crew:
		"""Creates the CompliancePolicy crew"""

		return Crew(
			agents=self.agents, # Automatically created by the @agent decorator
			tasks=self.tasks, # Automatically created by the @task decorator
			process=Process.sequential,
			verbose=True,
			# process=Process.hierarchical, # In case you wanna use that instead https://docs.crewai.com/how-to/Hierarchical/
		)
