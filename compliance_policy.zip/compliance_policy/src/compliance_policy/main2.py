#!/usr/bin/env python
import sys
import warnings

from manager import CompliancePolicy

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")


def run():
    """
    Run the crew.
    """
    inputs = {
        'human_task': 'Can you help me stay updated in the new labor laws and reccomendations to maintain compliance in the workplace.'
    }
    CompliancePolicy().crew().kickoff(inputs=inputs)


run()
