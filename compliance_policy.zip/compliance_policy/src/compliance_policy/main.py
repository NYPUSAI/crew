#!/usr/bin/env python
import sys
import warnings

from crew import CompliancePolicy

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")


def run():
    """
    Run the crew.
    """
    # inputs = {
    #     'topic': 'AI LLMs'
    # }
    CompliancePolicy().crew().kickoff()


run()
