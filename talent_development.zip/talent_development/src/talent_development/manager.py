from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from dotenv import load_dotenv
from typing import Optional
from pydantic import BaseModel,Field
from crewai_tools import CSVSearchTool,FileReadTool,DOCXSearchTool,PDFSearchTool,JSONSearchTool,SerperDevTool,YoutubeVideoSearchTool
load_dotenv()

class Talent_Development(BaseModel):
	training_needs_analyst_task_status: Optional[str] = Field(None,description="Status of the Training Needs ana;yst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	learning_consultant_task_status:  Optional[str] = Field(None,description="Status of the Learning consultant task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	instructional_designer_task_status:  Optional[str] = Field(None,description="Status of the Instructional Designer task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	lms_admin_task_status:  Optional[str] = Field(None,description="Status of the LMS Admin task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	training_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Training Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	learning_progress_tracker_task_status:  Optional[str] = Field(None,description="Status of the Learning Progress Tracker task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	feedback_analyst_task_status:  Optional[str] = Field(None,description="Status of the Feedback Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	certification_manager_task_status:  Optional[str] = Field(None,description="Status of the Certification Manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	cross_training_coordinator_status:  Optional[str] = Field(None,description="Status of the Cross Training Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	career_dev_specialist_status:  Optional[str] = Field(None,description="Status of the Career Development Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	employee_engagement_analyst_task_status:  Optional[str] = Field(None,description="Status of the Employee Engagement Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	recognition_specialist_task_status:  Optional[str] = Field(None,description="Status of the Recognition Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	feedback_analysis_expert_task_status:  Optional[str] = Field(None,description="Status of the Feedback Analysis Expert task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	team_building_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Team Building Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	work_anniversiary_manager_task_status:  Optional[str] = Field(None,description="Status of the Work Anniversary task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	performance_awards_coordinator_task_status:  Optional[str] = Field(None,description="Status of the Performance Awards Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	engagement_data_analyst_task_status:  Optional[str] = Field(None,description="Status of the Engagement Data Analyst task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	internal_communication_manager_task_status:  Optional[str] = Field(None,description="Status of the Internal Communication Manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	event_planner_task_status:  Optional[str] = Field(None,description="Status of the Event Planner task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	exit_interview_specialist_task_status:  Optional[str] = Field(None,description="Status of the Exit Interview Specialist task(eg: COMPLETED, IN_PROGRESS, FAILED)")


@CrewBase
class TalentDevelopment():
	"""TalentDevelopment crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'

	@agent
	def training_needs_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['training_needs_analyst'],
			verbose=True,
			tools=[CSVSearchTool()]
		)

	@agent
	def learning_consultant(self) -> Agent:
		return Agent(
			config=self.agents_config['learning_consultant'],
			verbose=True,
			tools=[YoutubeVideoSearchTool(),SerperDevTool()]
		)
	
	@agent
	def instructional_designer(self) -> Agent:
		return Agent(
			config=self.agents_config['instructional_designer'],
			verbose=True,
			tools=[YoutubeVideoSearchTool(),SerperDevTool()]
		)
	
	@agent
	def lms_admin(self) -> Agent:
		return Agent(
			config=self.agents_config['lms_admin'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def training_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['training_coordinator'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def learning_progress_tracker(self) -> Agent:
		return Agent(
			config=self.agents_config['learning_progress_tracker'],
			verbose=True,
			tools=[JSONSearchTool()]
		)
	
	@agent
	def feedback_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['feedback_analyst'],
			verbose=True,
			tools=[FileReadTool()]
		)
	
	@agent
	def certification_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['certification_manager'],
			verbose=True,
			tools=[JSONSearchTool()]
		)
	
	@agent
	def cross_training_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['cross_training_coordinator'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def career_dev_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['career_dev_specialist'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def employee_engagement_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['employee_engagement_analyst'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def recognition_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['recognition_specialist'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def feedback_analysis_expert(self) -> Agent:
		return Agent(
			config=self.agents_config['feedback_analysis_expert'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def team_building_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['team_building_coordinator'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def work_anniversiary_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['work_anniversiary_manager'],
			verbose=True,
			tools=[PDFSearchTool()]
		)
	
	@agent
	def performance_awards_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['performance_awards_coordinator'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def engagement_data_analyst(self) -> Agent:
		return Agent(
			config=self.agents_config['engagement_data_analyst'],
			verbose=True,
			tools=[DOCXSearchTool()]
		)
	
	@agent
	def internal_communication_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['internal_communication_manager'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def event_planner(self) -> Agent:
		return Agent(
			config=self.agents_config['event_planner'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def exit_interview_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['exit_interview_specialist'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def general_researcher(self) -> Agent:
		return Agent(
			config=self.agents_config['general_researcher'],
			verbose=True,
			tools=[]
		)
	
	@agent
	def general_researcher(self) -> Agent:
		return Agent(
			config=self.agents_config['general_researcher'],
			verbose=True,
			tools=[]
		)

	

	@task
	def training_needs_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['training_needs_analyst_task'],
		)
	
	@task
	def learning_consultant_task(self) -> Task:
		return Task(
			config=self.tasks_config['learning_consultant_task'],
		)
	
	@task
	def instructional_designer_task(self) -> Task:
		return Task(
			config=self.tasks_config['instructional_designer_task'],
		)
	
	@task
	def lms_admin_task(self) -> Task:
		return Task(
			config=self.tasks_config['lms_admin_task'],
		)
	
	@task
	def training_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['training_coordinator_task'],
		)
	
	@task
	def learning_progress_tracker_task(self) -> Task:
		return Task(
			config=self.tasks_config['learning_progress_tracker_task'],
		)
	
	@task
	def feedback_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['feedback_analyst_task'],
		)
	
	@task
	def certification_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['certification_manager_task'],
		)
	
	@task
	def cross_training_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['cross_training_coordinator_task'],
		)
	
	@task
	def career_dev_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['career_dev_specialist_task'],
		)
	
	@task
	def employee_engagement_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['employee_engagement_analyst_task'],
		)
	
	@task
	def recognition_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['recognition_specialist_task'],
		)
	
	@task
	def feedback_analysis_expert_task(self) -> Task:
		return Task(
			config=self.tasks_config['feedback_analysis_expert_task'],
		)
	
	@task
	def team_building_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['team_building_coordinator_task'],
		)
	
	@task
	def work_anniversiary_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['work_anniversiary_manager_task'],
		)
	
	@task
	def performance_awards_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['performance_awards_coordinator_task'],
		)
	
	@task
	def engagement_data_analyst_task(self) -> Task:
		return Task(
			config=self.tasks_config['engagement_data_analyst_task'],
		)
	
	@task
	def internal_communication_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['internal_communication_manager_task'],
		)
	
	@task
	def event_planner_task(self) -> Task:
		return Task(
			config=self.tasks_config['event_planner_task'],
		)
	
	@task
	def exit_interview_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['exit_interview_specialist_task'],
		)
	
	@task
	def task_completion_status(self) -> Task:
		return Task(
			config=self.tasks_config['task_completion_status'],
			output_pydantic=Talent_Development
		)


	
	@agent
	def manager(self) -> Agent:
		return Agent(
			role="Task Manager",
            goal="Efficiently identify, delegate, and oversee the execution of tasks based on user input, ensuring timely and accurate completion while maintaining clear communication with the user.",
            verbose=True,
            tools=[],
            backstory=(
                """
                You are a highly organized and detail-oriented professional with extensive experience in task management and delegation. 
                Your expertise lies in understanding complex requirements, matching tasks to the right resources, and ensuring seamless execution.
                With a strong focus on efficiency and accountability, you thrive in dynamic environments where multiple tasks need to be managed simultaneously.
                Your ability to communicate clearly and monitor progress ensures that tasks are completed on time and meet the highest standards of quality.
                """
            ),
            allow_delegation=True,
            memory=True
        )
	@task
	def process_pending_tasks_task(self) -> Task:
		return Task(
            description=(
		"""
		Take the task provided by the user (`{human_task}`) and determine which agent is best suited to execute it based on the agent's role and capabilities.

		Steps to follow:
		1. **Analyze the Task**: Carefully read and understand the task provided by the user. Identify the key requirements and objectives of the task.
		2. **Match Task to Agent**: Review the roles and capabilities of all available agents. Match the task to the most appropriate agent based on their expertise and tools.
		3. **Delegate the Task**: If a suitable agent is found, delegate the task to that agent and ensure they execute it properly. Provide the agent with all necessary information and context.
		4. **Handle Unmatched Tasks**: If no suitable agent is available to handle the task, inform the user that the task cannot be executed and provide a reason why.
		5. **Monitor Progress**: Continuously monitor the progress of the task. If the task fails or encounters issues, update the task status accordingly and inform the user.
		6. **Ensure Completion**: Once the task is completed, verify that the output meets the user's expectations and update the task status to "COMPLETED".

		Ensure that all tasks are executed efficiently and that the user is kept informed of the progress and any issues that arise.
		"""
		),
		expected_output="""
		The task provided by the user should be executed by the appropriate agent, and the results obtained by the agent should be shown to the user.
		If the task cannot be executed, the user should be informed with a clear explanation.
		The task status should be updated dynamically based on the progress and outcome of the task.
		""",
        )

	@crew
	def crew(self) -> Crew:
		"""Creates the ProjectPlanner crew"""
		return Crew(
            agents=[self.training_needs_analyst(),
					self.learning_consultant(),
					self.instructional_designer(),
					self.lms_admin(),
                    self.training_coordinator(),
                    self.learning_progress_tracker(),
                    self.feedback_analyst(),
                    self.certification_manager(),
                    self.cross_training_coordinator(),
                    self.career_dev_specialist(),
                    self.employee_engagement_analyst(),
                    self.recognition_specialist(),
                    self.feedback_analysis_expert(),
                    self.team_building_coordinator(),
                    self.work_anniversiary_manager(),
                    self.performance_awards_coordinator(),
					self.engagement_data_analyst(),
					self.internal_communication_manager(),
					self.event_planner(),
					self.exit_interview_specialist(),
                    self.general_researcher(),],
			tasks=[self.process_pending_tasks_task(),],
			process=Process.hierarchical,
			verbose=True,
			manager_agent=self.manager(),
    )

