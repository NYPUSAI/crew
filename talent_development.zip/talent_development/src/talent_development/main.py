#!/usr/bin/env python
import sys
import warnings

from crew import TalentDevelopment

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")


def run():
    """
    Run the crew.
    """
    # inputs = {
    #     'topic': 'AI LLMs'
    # }
    TalentDevelopment().crew().kickoff()

run()
