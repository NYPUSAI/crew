#!/usr/bin/env python
import sys
import warnings

from manager import TalentDevelopment

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")


def run():
    """
    Run the crew.
    """
    inputs = {
        'human_task': 'Can you suggest a team building to coordinate to foster teamwork'
    }
    TalentDevelopment().crew().kickoff(inputs=inputs)

run()
