#!/usr/bin/env python
import sys
import warnings

from datetime import datetime

from crew import SocialMediaCrew

# Suppress SyntaxWarnings related to pysbd (if applicable)
warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")

def run():
    """
    Run the crew.
    """
    # Define structured input variables
    competitors = "Nike, Adidas, Puma"
    campaign_theme = "New Year Fitness Goals"
    target_audience = "Gen Z"
    platform = "Instagram, Twitter"
    goal = "Increase brand engagement by 20%"

    # Format the topic as a clear sentence
    topic = (f"Develop a social media campaign for {campaign_theme}, targeting {target_audience} on {platform}. "
             f"Analyze competitor strategies from {competitors} and implement content ideas to achieve the goal: {goal}.")

    # Define structured inputs for the CrewAI task
    inputs = {
        'topic': topic
    }

    try:
        SocialMediaCrew().crew().kickoff(inputs=inputs)
    except Exception as e:
        raise Exception(f"An error occurred while running the crew: {e}")

if __name__ == "__main__":
    run()
