import sys
import warnings

from manager import BudgetQuality

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")


def run():
    """
    Run the crew.
    """
    inputs = {
        "human_task":" Can you help coordinate a training session for the team on Deepseek AI on Feb 20 2025."
    }
    BudgetQuality().crew().kickoff(inputs=inputs)

run()