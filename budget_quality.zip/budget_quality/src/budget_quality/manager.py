from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from dotenv import load_dotenv
from crewai_tools import CSVSearchTool,PDFSearchTool,DirectoryReadTool,YoutubeVideoSearchTool,SerperDevTool
from typing import Optional
from pydantic import BaseModel,Field

load_dotenv()

class Budget_Quality(BaseModel):
	budget_manager_task_status: Optional[str] = Field(None,description="Status of the Budget manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	quality_assurance_task_status:  Optional[str] = Field(None,description="Status of the Quality assurance task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	documentation_specialist_task_status:  Optional[str] = Field(None,description="Status of the Document Specilaist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	training_coordinato_task_status:  Optional[str] = Field(None,description="Status of the Training Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	vendor_reln_manager_task_status:  Optional[str] = Field(None,description="Status of the Vendor Manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")

@CrewBase
class BudgetQuality():
	"""BudgetQuality crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'

	@agent
	def budget_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['budget_manager'],
			verbose=True,
			tools=[CSVSearchTool()]
		)

	@agent
	def quality_assurance(self) -> Agent:
		return Agent(
			config=self.agents_config['quality_assurance'],
			verbose=True,
			tools=[PDFSearchTool()]
		)
	
	@agent
	def documentation_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['documentation_specialist'],
			verbose=True,
			tools=[DirectoryReadTool()]
		)
	
	@agent
	def training_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['training_coordinator'],
			verbose=True,
			tools=[YoutubeVideoSearchTool()]
		)
	
	@agent
	def vendor_reln_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['vendor_reln_manager'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	
	@agent
	def general_researcher(self) -> Agent:
		return Agent(
			config=self.agents_config['general_researcher'],
			verbose=True,
			tools=[]
		)

	@task
	def budget_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['budget_manager_task'],
		)
	
	@task
	def quality_assurance_task(self) -> Task:
		return Task(
			config=self.tasks_config['quality_assurance_task'],
		)
	
	@task
	def documentation_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['documentation_specialist_task'],
		)
	
	@task
	def training_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['training_coordinator_task'],
		)
	
	@task
	def vendor_reln_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['vendor_reln_manager_task'],
		)

	@task
	def task_completion_status(self) -> Task:
		return Task(
			config=self.tasks_config['task_completion_status'],
			output_pydantic=Budget_Quality
		)

	@agent
	def manager(self) -> Agent:
		return Agent(
			role="Task Manager",
            goal="Efficiently identify, delegate, and oversee the execution of tasks based on user input, ensuring timely and accurate completion while maintaining clear communication with the user.",
            verbose=True,
            tools=[],
            backstory=(
                """
                You are a highly organized and detail-oriented professional with extensive experience in task management and delegation. 
                Your expertise lies in understanding complex requirements, matching tasks to the right resources, and ensuring seamless execution.
                With a strong focus on efficiency and accountability, you thrive in dynamic environments where multiple tasks need to be managed simultaneously.
                Your ability to communicate clearly and monitor progress ensures that tasks are completed on time and meet the highest standards of quality.
                """
            ),
            allow_delegation=True,
            memory=True
        )
	@task
	def process_pending_tasks_task(self) -> Task:
		return Task(
            description=(
		"""
		Take the task provided by the user (`{human_task}`) and determine which agent is best suited to execute it based on the agent's role and capabilities.

		Steps to follow:
		1. **Analyze the Task**: Carefully read and understand the task provided by the user. Identify the key requirements and objectives of the task.
		2. **Match Task to Agent**: Review the roles and capabilities of all available agents. Match the task to the most appropriate agent based on their expertise and tools.
		3. **Delegate the Task**: If a suitable agent is found, delegate the task to that agent and ensure they execute it properly. Provide the agent with all necessary information and context.
		4. **Handle Unmatched Tasks**: If no suitable agent is available to handle the task, inform the user that the task cannot be executed and provide a reason why.
		5. **Monitor Progress**: Continuously monitor the progress of the task. If the task fails or encounters issues, update the task status accordingly and inform the user.
		6. **Ensure Completion**: Once the task is completed, verify that the output meets the user's expectations and update the task status to "COMPLETED".

		Ensure that all tasks are executed efficiently and that the user is kept informed of the progress and any issues that arise.
		"""
		),
		expected_output="""
		The task provided by the user should be executed by the appropriate agent, and the results obtained by the agent should be shown to the user.
		If the task cannot be executed, the user should be informed with a clear explanation.
		The task status should be updated dynamically based on the progress and outcome of the task.
		""",
        )

	@crew
	def crew(self) -> Crew:
		"""Creates the ProjectPlanner crew"""
		return Crew(
            agents=[self.budget_manager(),
					self.quality_assurance(),
					self.documentation_specialist(),
					self.training_coordinator(),
					self.vendor_reln_manager(),
                    self.general_researcher(),],
			tasks=[self.process_pending_tasks_task(),],
			process=Process.hierarchical,
			verbose=True,
			manager_agent=self.manager(),
    )
