from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from dotenv import load_dotenv
from crewai_tools import CSVSearchTool,PDFSearchTool,DirectoryReadTool,YoutubeVideoSearchTool,SerperDevTool
from typing import Optional
from pydantic import BaseModel,Field

load_dotenv()

class Budget_Quality(BaseModel):
	budget_manager_task_status: Optional[str] = Field(None,description="Status of the Budget manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	quality_assurance_task_status:  Optional[str] = Field(None,description="Status of the Quality assurance task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	documentation_specialist_task_status:  Optional[str] = Field(None,description="Status of the Document Specilaist task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	training_coordinato_task_status:  Optional[str] = Field(None,description="Status of the Training Coordinator task(eg: COMPLETED, IN_PROGRESS, FAILED)")
	vendor_reln_manager_task_status:  Optional[str] = Field(None,description="Status of the Vendor Manager task(eg: COMPLETED, IN_PROGRESS, FAILED)")

@CrewBase
class BudgetQuality():
	"""BudgetQuality crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'

	@agent
	def budget_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['budget_manager'],
			verbose=True,
			tools=[CSVSearchTool()]
		)

	@agent
	def quality_assurance(self) -> Agent:
		return Agent(
			config=self.agents_config['quality_assurance'],
			verbose=True,
			tools=[PDFSearchTool()]
		)
	
	@agent
	def documentation_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['documentation_specialist'],
			verbose=True,
			tools=[DirectoryReadTool()]
		)
	
	@agent
	def training_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['training_coordinator'],
			verbose=True,
			tools=[YoutubeVideoSearchTool()]
		)
	
	@agent
	def vendor_reln_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['vendor_reln_manager'],
			verbose=True,
			tools=[SerperDevTool()]
		)
	
	@agent
	def general_researcher(self) -> Agent:
		return Agent(
			config=self.agents_config['general_researcher'],
			verbose=True,
			tools=[]
		)

	@task
	def budget_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['budget_manager_task'],
		)
	
	@task
	def quality_assurance_task(self) -> Task:
		return Task(
			config=self.tasks_config['quality_assurance_task'],
		)
	
	@task
	def documentation_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['documentation_specialist_task'],
		)
	
	@task
	def training_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['training_coordinator_task'],
		)
	
	@task
	def vendor_reln_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['vendor_reln_manager_task'],
		)

	@task
	def task_completion_status(self) -> Task:
		return Task(
			config=self.tasks_config['task_completion_status'],
			output_pydantic=Budget_Quality
		)

	@crew
	def crew(self) -> Crew:
		"""Creates the BudgetQuality crew"""


		return Crew(
			agents=self.agents, # Automatically created by the @agent decorator
			tasks=self.tasks, # Automatically created by the @task decorator
			process=Process.sequential,
			verbose=True,
			# process=Process.hierarchical, # In case you wanna use that instead https://docs.crewai.com/how-to/Hierarchical/
		)
