import warnings
warnings.filterwarnings('ignore')

from crewai import Agent, Task, Crew, Process
from crewai_tools import SerperDevTool
import os
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY is not set in environment variables.")

# State file for memory persistence
STATE_FILE = "job_posting_state.json"

# Helper functions for state management
def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as file:
            return json.load(file)
    return {}

def save_state(state):
    with open(STATE_FILE, "w") as file:
        json.dump(state, file)

# Load the current state
state = load_state()

# Define tools
search_tool = SerperDevTool()

# Define agents
job_posting_agent = Agent(
    role="Job Posting Specialist",
    goal="Create job postings for open positions.",
    backstory=(
        "You specialize in crafting attractive and informative job postings. "
        "Your job is to ensure the postings effectively communicate the role and "
        "attract top talent."
    ),
    verbose=True
)

screening_agent = Agent(
    role="Candidate Screening Specialist",
    goal="Screen candidate applications and provide shortlists.",
    backstory=(
        "You are an expert in evaluating candidate profiles and selecting the best "
        "fits for job positions. You ensure thorough and accurate screenings."
    ),
    verbose=True
)

# Define tasks
job_posting_task = Task(
    description=(
        "Create a job posting for the role of {job_title}. Ensure the posting includes the "
        "job description, qualifications, responsibilities, and company information."
    ),
    expected_output=(
        "A comprehensive job posting for the specified role, formatted professionally."
    ),
    tools=[search_tool],
    agent=job_posting_agent
)

screening_task = Task(
    description=(
        "Screen applications for the position of {job_title}. "
        "Identify the top candidates based on their qualifications and experience."
    ),
    expected_output=(
        "A shortlist of top candidates with explanations for their selection."
    ),
    tools=[search_tool],
    agent=screening_agent
)

# Check memory and adjust tasks
tasks = []
if not state.get("job_posting_done", False):
    tasks.append(job_posting_task)  # Add job posting task if not already done
else:
    print("Job posting already exists. Skipping job posting task.")
tasks.append(screening_task)  # Always include the screening task

# Create the Crew
crew = Crew(
    agents=[job_posting_agent, screening_agent],
    tasks=tasks,
    process=Process.sequential,  # Tasks executed in order
    verbose=True
)

# Inputs for the Crew
inputs = {
    "job_title": "Software Engineer"
}

# Run the Crew
result = crew.kickoff(inputs=inputs)

# Update memory after job posting creation
if not state.get("job_posting_done", False):
    state["job_posting_done"] = True
    state["job_title"] = inputs["job_title"]
    save_state(state)

# Display the result
print("Crew Output:")
print(result)
