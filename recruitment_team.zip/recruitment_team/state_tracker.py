import json
import os

STATE_FILE = "task_state.json"

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as file:
            return json.load(file)
    return {}

def save_state(state):
    with open(STATE_FILE, "w") as file:
        json.dump(state, file)
