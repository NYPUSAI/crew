from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task


@CrewBase
class RecruitmentTeam():
	"""RecruitmentTeam crew"""

	agents_config = 'config/agents.yaml'
	tasks_config = 'config/tasks.yaml'

	@agent
	def job_posting_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['job_posting_specialist'],
			verbose=True
		)
	@agent
	def sourcing_automation_agent(self) -> Agent:
		return Agent(
			config=self.agents_config['sourcing_automation_agent'],
			verbose=True
		)
	
	@agent
	def resume_screening_agent(self) -> Agent:
		return Agent(
			config=self.agents_config['resume_screening_agent'],
			verbose=True
		)
	
	@agent
	def candidate_outreach_specialist(self) -> Agent:
		return Agent(
			config=self.agents_config['candidate_outreach_specialist'],
			verbose=True
		)
	
	@agent
	def assessment_chatbot(self) -> Agent:
		return Agent(
			config=self.agents_config['assessment_chatbot'],
			verbose=True
		)
	
	@agent
	def interview_coordinator(self) -> Agent:
		return Agent(
			config=self.agents_config['interview_coordinator'],
			verbose=True
		)
	
	@agent
	def interview_preparation_agent(self) -> Agent:
		return Agent(
			config=self.agents_config['interview_preparation_agent'],
			verbose=True
		)
	
	@agent
	def reference_check_agent(self) -> Agent:
		return Agent(
			config=self.agents_config['reference_check_agent'],
			verbose=True
		)
	
	@agent
	def offer_letter_generator(self) -> Agent:
		return Agent(
			config=self.agents_config['offer_letter_generator'],
			verbose=True
		)
	
	@agent
	def ats_manager(self) -> Agent:
		return Agent(
			config=self.agents_config['ats_manager'],
			verbose=True
		)

	@agent
	def summary_agent(self) -> Agent:
		return Agent(
			config=self.agents_config['summary_agent'],
			verbose=True
		)
	
	@task
	def job_posting_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['job_posting_specialist_task'],
		)
	
	@task
	def sourcing_automation_agent_task(self) -> Task:
		return Task(
			config=self.tasks_config['sourcing_automation_agent_task'],
		)
	
	@task
	def resume_screening_agent_task(self) -> Task:
		return Task(
			config=self.tasks_config['resume_screening_agent_task'],
		)
	
	@task
	def candidate_outreach_specialist_task(self) -> Task:
		return Task(
			config=self.tasks_config['candidate_outreach_specialist_task'],
		)
	
	@task
	def assessment_chatbot_task(self) -> Task:
		return Task(
			config=self.tasks_config['assessment_chatbot_task'],
		)
	
	@task
	def interview_coordinator_task(self) -> Task:
		return Task(
			config=self.tasks_config['interview_coordinator_task'],
		)
	
	@task
	def interview_preparation_agent_task(self) -> Task:
		return Task(
			config=self.tasks_config['interview_preparation_agent_task'],
		)
	
	@task
	def reference_check_agent_task(self) -> Task:
		return Task(
			config=self.tasks_config['reference_check_agent_task'],
		)
	
	@task
	def offer_letter_generator_task(self) -> Task:
		return Task(
			config=self.tasks_config['offer_letter_generator_task'],
		)
	
	@task
	def ats_manager_task(self) -> Task:
		return Task(
			config=self.tasks_config['ats_manager_task'],
		)
	
	@task
	def summary_agent_task(self) -> Task:
		return Task(
			config=self.tasks_config['summary_agent_task'],
		)
	

	@crew
	def crew(self) -> Crew:
		"""Creates the RecruitmentTeam crew"""


		return Crew(
			agents=self.agents, # Automatically created by the @agent decorator
			tasks=self.tasks, # Automatically created by the @task decorator
			process=Process.hierarchical,
			verbose=True,
			manager_llm="gpt-3.5-turbo"
			# process=Process.hierarchical, # In case you wanna use that instead https://docs.crewai.com/how-to/Hierarchical/
		)
