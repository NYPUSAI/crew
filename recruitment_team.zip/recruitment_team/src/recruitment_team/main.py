#!/usr/bin/env python
import sys
import warnings
from dotenv import load_dotenv

load_dotenv()

from crew import RecruitmentTeam

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pysbd")


def run():
    """
    Run the crew.
    """
    inputs={
                "job_title": "Software Engineer",
                "job_requirements": "Proficient in Python and JavaScript.",
            }
    RecruitmentTeam().crew().kickoff(inputs=inputs)

run()
