from crewai import Crew, Process
from langchain_openai import ChatOpenAI
from agents import BudgetingForecastingAgents
from tasks import BudgetingForecastingTasks
from dotenv import load_dotenv
from crewai import Task

load_dotenv()

# Initialize agents and tasks
agents = BudgetingForecastingAgents()
tasks = BudgetingForecastingTasks()

# Initialize the OpenAI GPT-3.5 language model
manager_llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7)

# Instantiate agents
budgeting_specialist_agent = agents.budgeting_specialist_agent()
trend_analyst_agent = agents.trend_analyst_agent()
finance_automation_expert_agent = agents.finance_automation_expert_agent()
revenue_forecaster_agent = agents.revenue_forecaster_agent()
financial_scenario_planner_agent = agents.financial_scenario_planner_agent()
capex_opex_analyst_agent = agents.capex_opex_analyst_agent()
budget_utilization_monitor_agent = agents.budget_utilization_monitor_agent()
market_intelligence_specialist_agent = agents.market_intelligence_specialist_agent()
cost_optimization_analyst_agent = agents.cost_optimization_analyst_agent()
predictive_cost_analyst_agent = agents.predictive_cost_analyst_agent()
general_research_agent = agents.general_research_agent()
task_manager_agent = agents.task_manager_agent()

# Instantiate tasks
budget_template_task = tasks.budget_template_task(budgeting_specialist_agent, 1111)
trend_analysis_task = tasks.trend_analysis_task(trend_analyst_agent, 2222)
budget_approval_task = tasks.budget_approval_task(finance_automation_expert_agent, 3333)
revenue_forecasting_task = tasks.revenue_forecast_task(revenue_forecaster_agent, 4444)
financial_projection_task = tasks.financial_projection_task(financial_scenario_planner_agent, 5555)
capex_opex_forecast_task = tasks.capex_opex_forecast_task(capex_opex_analyst_agent, 6666)
budget_utilization_task = tasks.budget_utilization_task(budget_utilization_monitor_agent, 7777)
market_adjusted_forecast_task = tasks.market_adjusted_forecast_task(market_intelligence_specialist_agent, 8888)
cost_saving_task = tasks.cost_saving_task(cost_optimization_analyst_agent, 9999)
predictive_cost_task = tasks.predictive_cost_task(predictive_cost_analyst_agent, 1000)
find_initial_information_task = tasks.find_initial_information_task(task_manager_agent, 1234)


inputs = {
    "company_name": "ABC Corporation",
    "location": "San Francisco",

    "historical_financials_path": "Budgeting_Inputs/Historical/historical_financials_2025.xlsx",
    "revenue_trends_path": "Budgeting_Inputs/Trends/revenue_trends_feb2025.csv",
    "expense_trends_path": "Budgeting_Inputs/Trends/expense_trends_feb2025.xlsx",
    "market_data_path": "Budgeting_Inputs/Market/market_trends_2025.json",
    "capex_data_path": "Budgeting_Inputs/CAPEX/capex_opex_data_feb2025.xlsx",
    "budget_allocation_path": "Budgeting_Inputs/Budget/budget_allocation_2025.xlsx",
    "forecast_settings_path": "Budgeting_Inputs/Automation/forecast_settings.json",
}

process_pending_tasks_task = Task(
    description=(
    """
    Analyze user-defined tasks, determine the best-suited agent, and ensure task execution.
    Steps:
    1. **Analyze Task**: Identify key requirements and objectives.
    2. **Match Task to Agent**: Assign to the most relevant agent.
    3. **Execute Task**: Provide required inputs and monitor execution.
    4. **Handle Unmatched Tasks**: Inform users if no suitable agent is found.
    5. **Track Progress**: Monitor and update task status.
    6. **Verify Completion**: Ensure outputs meet expectations.
    """
    ),
    expected_output="""
    The assigned agent successfully executes the user-defined task, and results are returned. 
    If execution isn't possible, the user is informed with a clear explanation.
    """,
)

crew = Crew(
    agents=[
        budgeting_specialist_agent,
        trend_analyst_agent,
        finance_automation_expert_agent,
        revenue_forecaster_agent,
        financial_scenario_planner_agent,
        capex_opex_analyst_agent,
        budget_utilization_monitor_agent,
        market_intelligence_specialist_agent,
        cost_optimization_analyst_agent,
        predictive_cost_analyst_agent,
        task_manager_agent
    ],
    tasks=[
        budget_template_task,
        trend_analysis_task,
        budget_approval_task,
        revenue_forecasting_task,
        financial_projection_task,
        capex_opex_forecast_task,
        budget_utilization_task,
        market_adjusted_forecast_task,
        cost_saving_task,
        predictive_cost_task,
        find_initial_information_task
    ],
    process=Process.sequential
)

# Execute crew
result = crew.kickoff()
print(result)

# Crew setup for hierarchical human task management
human_task_crew = Crew(
    agents=[
        budgeting_specialist_agent,
        trend_analyst_agent,
        finance_automation_expert_agent,
        revenue_forecaster_agent,
        financial_scenario_planner_agent,
        capex_opex_analyst_agent,
        budget_utilization_monitor_agent,
        market_intelligence_specialist_agent,
        cost_optimization_analyst_agent,
        predictive_cost_analyst_agent,
        task_manager_agent
    ],
    tasks=[process_pending_tasks_task],
    process=Process.hierarchical,
    manager_llm=manager_llm,
    verbose=True,
    manager_agent=agents.task_manager_agent()
)

human_inputs = {
    "human_task": "Generate a financial forecast based on recent revenue and expense trends."
}

human_result = human_task_crew.kickoff()
print(human_result)
