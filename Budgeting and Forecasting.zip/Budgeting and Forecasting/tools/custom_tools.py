import json
import os
import requests
import pandas as pd
from bs4 import BeautifulSoup
from datetime import datetime
from langchain.tools import tool

class CustomTools:
    
    @tool("ForecastingAPIConnector")
    def fetch_forecasted_data(api_url, api_key, parameters):
        """Integrates with external forecasting APIs to enhance predictive analysis."""
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        response = requests.get(api_url, headers=headers, params=parameters)
        
        if response.status_code != 200:
            return f"Error fetching forecasted data: {response.status_code}"
        
        data = response.json()
        return data if data else "No forecast data available."
    
    @tool("MarketSentimentScraper")
    def scrape_market_sentiment(url):
        """Scrapes financial websites to gather real-time market sentiment."""
        headers = {"User-Agent": "Mozilla/5.0"}
        response = requests.get(url, headers=headers)
        
        if response.status_code != 200:
            return f"Error accessing {url}. Status Code: {response.status_code}"
        
        soup = BeautifulSoup(response.text, 'html.parser')
        headlines = [h.text for h in soup.find_all('h2')][:5]  # Extract top headlines
        return headlines if headlines else "No market sentiment data found."
    
    @tool("AutomationWorkflowTool")
    def automate_budget_approval(workflow_data_path, output_path="approved_budgets.xlsx"):
        """Automates budget approval workflows using internal ERP systems."""
        df = pd.read_excel(workflow_data_path)
        
        # Simulating an approval process (e.g., auto-approving budgets within a threshold)
        df["Status"] = df["Amount"].apply(lambda x: "Approved" if x < 50000 else "Pending Review")
        
        df.to_excel(output_path, index=False)
        return f"Budget approval workflow processed and saved to {output_path}"
