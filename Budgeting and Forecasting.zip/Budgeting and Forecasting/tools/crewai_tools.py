import json
import os
import csv
import PyPDF2
import requests
from bs4 import BeautifulSoup
from langchain.tools import tool

class BudgetingForecastingTools:
    
    @tool("CSVSearchTool")
    def search_csv(file_path: str, search_term: str):
        """Search and retrieve specific financial data from CSV budget reports."""
        if not os.path.exists(file_path):
            return f"Error: File {file_path} not found."
        
        results = []
        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                if search_term.lower() in str(row).lower():
                    results.append(row)
        
        return results if results else "No matching transactions found."

    @tool("JSONSearchTool")
    def search_json(file_path: str, key: str):
        """Extract structured budget and forecasting data from JSON files."""
        if not os.path.exists(file_path):
            return f"Error: File {file_path} not found."
        
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return data.get(key, "Key not found in JSON file.")
    
    @tool("PDFSearchTool")
    def extract_pdf_text(file_path: str):
        """Retrieve financial reports and trend analysis from PDF documents."""
        if not os.path.exists(file_path):
            return f"Error: File {file_path} not found."
        
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            text = "\n".join([page.extract_text() for page in reader.pages if page.extract_text()])
        
        return text if text else "No text found in PDF."
    
    @tool("SerperDevTool")
    def search_internet(query: str):
        """Fetch real-time market trends and financial news for forecasting."""
        url = "https://serpapi.com/search.json"
        params = {
            "q": query,
            "api_key": os.environ.get('SERPAPI_KEY', '')
        }
        
        response = requests.get(url, params=params)
        if response.status_code != 200:
            return "Error retrieving search results."
        
        data = response.json()
        results = data.get('organic_results', [])[:4]
        return "\n".join([f"Title: {r['title']}\nLink: {r['link']}\nSnippet: {r.get('snippet', 'No snippet')}\n" for r in results])
    
    @tool("FileReadTool")
    def read_file(file_path: str):
        """Read budget templates and financial reports stored in files."""
        if not os.path.exists(file_path):
            return f"Error: File {file_path} not found."
        
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    @tool("WebsiteSearchTool")
    def search_finance_websites(query: str):
        """Search external finance websites for cost-saving strategies."""
        search_urls = [
            "https://www.investopedia.com/search?q=", 
            "https://www.forbes.com/search/?q=", 
            "https://www.wsj.com/search?query="
        ]
        
        headers = {'User-Agent': 'Mozilla/5.0'}
        results = []
        for base_url in search_urls:
            url = f"{base_url}{query}"
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                links = soup.find_all('a', href=True)
                for link in links[:5]:
                    results.append(link['href'])
        
        return results if results else "No relevant articles found."
