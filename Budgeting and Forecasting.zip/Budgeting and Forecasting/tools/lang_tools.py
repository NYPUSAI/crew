import os
import openpyxl
import sqlite3
import pandas as pd
from langchain.tools import tool

# Excel Reader Tool
class ExcelReaderTool:
    
    @tool("Read and manipulate financial data from Excel spreadsheets")
    def read_excel_data(file_path: str, sheet_name: str = None):
        """Reads and extracts financial data from Excel spreadsheets for budget and forecast analysis."""
        try:
            if not os.path.exists(file_path):
                return "Error: Excel file not found."
            
            wb = openpyxl.load_workbook(file_path)
            sheet = wb[sheet_name] if sheet_name else wb.active
            
            data = []
            for row in sheet.iter_rows(values_only=True):
                data.append(row)
            
            return data if data else "No data found in the sheet."
        except Exception as e:
            return f"Error reading Excel file: {e}"

# SQL Database Chain
class SQLDatabaseChain:
    
    @tool("Query and analyze financial data stored in SQL databases")
    def query_sql_database(db_path: str, query: str):
        """Executes SQL queries to fetch and analyze financial data from structured databases."""
        try:
            if not os.path.exists(db_path):
                return "Error: Database file not found."
            
            conn = sqlite3.connect(db_path)
            df = pd.read_sql_query(query, conn)
            conn.close()
            
            return df.to_dict(orient="records") if not df.empty else "No data found."
        except Exception as e:
            return f"Error executing SQL query: {e}"