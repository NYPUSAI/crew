from pydantic import BaseModel, Field
from crewai import Task
from typing import Optional, List, Dict, Literal
from langchain.tools import BaseTool

class BudgetTemplate(BaseModel):
    business_unit: str
    template_structure: str

class TrendAnalysis(BaseModel):
    historical_data_used: List[str]
    market_trends_identified: List[str]

class BudgetApprovalWorkflow(BaseModel):
    steps: List[str]
    automation_status: str

class RevenueForecast(BaseModel):
    historical_data_referenced: List[str]
    projected_growth: float

class FinancialProjection(BaseModel):
    scenarios: Dict[str, str]
    key_variables: List[str]

class CapexOpexForecast(BaseModel):
    capex_forecast: float
    opex_forecast: float
    methodology: str

class BudgetUtilization(BaseModel):
    departments_monitored: List[str]
    utilization_report: Dict[str, float]

class MarketAdjustedForecast(BaseModel):
    adjusted_projections: Dict[str, float]
    external_factors_considered: List[str]

class CostSavingOpportunities(BaseModel):
    potential_savings: Dict[str, float]
    recommendations: List[str]

class PredictiveCostAnalysis(BaseModel):
    ai_model_used: str
    predicted_cost_trends: Dict[str, float]

class BudgetingTaskStatus(BaseModel):
    budget_template_task_status: Optional[str] = Field(None, description="Status of Budget Template Preparation Task")
    trend_analysis_task_status: Optional[str] = Field(None, description="Status of Trend Analysis Task")
    budget_approval_task_status: Optional[str] = Field(None, description="Status of Automated Budget Approval Workflow Task")
    revenue_forecast_task_status: Optional[str] = Field(None, description="Status of Revenue Forecasting Task")
    financial_projection_task_status: Optional[str] = Field(None, description="Status of Multi-Scenario Financial Projections Task")
    capex_opex_forecast_task_status: Optional[str] = Field(None, description="Status of CAPEX and OPEX Forecasting Task")
    budget_utilization_task_status: Optional[str] = Field(None, description="Status of Real-Time Budget Utilization Monitoring Task")
    market_adjusted_forecast_task_status: Optional[str] = Field(None, description="Status of Market-Adjusted Financial Forecasting Task")
    cost_saving_task_status: Optional[str] = Field(None, description="Status of Cost-Saving Opportunity Analysis Task")
    predictive_cost_task_status: Optional[str] = Field(None, description="Status of Predictive Cost Analysis Task")

class BudgetingForecastingTasks:
    
    def budget_template_task(self, agent, chat_message_id):
        return Task(
            description="Prepare comprehensive budget templates for various business units.",
            agent=agent,
            async_execution=True,
            expected_output='''
BudgetTemplate(
    business_unit="Sales Department",
    template_structure="Revenue, Expenses, Profit, Forecast"
)
''',
            chat_message_id=chat_message_id
        )

    def trend_analysis_task(self, agent, chat_message_id):
        return Task(
            description="Conduct trend analysis using past financial data and market reports.",
            agent=agent,
            async_execution=True,
            expected_output='''
TrendAnalysis(
    historical_data_used=["2023 Sales Data", "2024 Q1 Performance"],
    market_trends_identified=["Increasing demand for AI solutions", "Declining hardware sales"]
)
''',
            chat_message_id=chat_message_id
        )

    def budget_approval_task(self, agent, chat_message_id):
        return Task(
            description="Develop automated workflows for budget approvals.",
            agent=agent,
            async_execution=True,
            expected_output='''
BudgetApprovalWorkflow(
    steps=["Department Submission", "Manager Review", "Finance Approval", "Final Execution"],
    automation_status="Fully Automated"
)
''',
            chat_message_id=chat_message_id
        )

    def revenue_forecast_task(self, agent, chat_message_id):
        return Task(
            description="Forecast revenue growth based on historical and external data.",
            agent=agent,
            async_execution=True,
            expected_output='''
RevenueForecast(
    historical_data_referenced=["2022 Financials", "2023 Market Analysis"],
    projected_growth=12.5
)
''',
            chat_message_id=chat_message_id
        )

    def financial_projection_task(self, agent, chat_message_id):
        return Task(
            description="Create multi-scenario financial projections based on key variables.",
            agent=agent,
            async_execution=True,
            expected_output='''
FinancialProjection(
    scenarios={"Optimistic": "15% Growth", "Pessimistic": "5% Decline"},
    key_variables=["Market Demand", "Interest Rates", "Operating Costs"]
)
''',
            chat_message_id=chat_message_id
        )

    def capex_opex_forecast_task(self, agent, chat_message_id):
        return Task(
            description="Develop automated forecasting models for CAPEX and OPEX.",
            agent=agent,
            async_execution=True,
            expected_output='''
CapexOpexForecast(
    capex_forecast=500000.0,
    opex_forecast=200000.0,
    methodology="Regression Analysis with AI"
)
''',
            chat_message_id=chat_message_id
        )

    def budget_utilization_task(self, agent, chat_message_id):
        return Task(
            description="Monitor real-time budget utilization across departments.",
            agent=agent,
            async_execution=True,
            expected_output='''
BudgetUtilization(
    departments_monitored=["Marketing", "R&D", "Operations"],
    utilization_report={"Marketing": 80.0, "R&D": 60.0, "Operations": 75.0}
)
''',
            chat_message_id=chat_message_id
        )

    def market_adjusted_forecast_task(self, agent, chat_message_id):
        return Task(
            description="Adjust financial forecasts based on real-time market trends.",
            agent=agent,
            async_execution=True,
            expected_output='''
MarketAdjustedForecast(
    adjusted_projections={"Revenue": 1050000.0, "Expenses": 750000.0},
    external_factors_considered=["Inflation Impact", "Supply Chain Disruptions"]
)
''',
            chat_message_id=chat_message_id
        )

    def cost_saving_task(self, agent, chat_message_id):
        return Task(
            description="Suggest cost-saving opportunities based on financial data analysis.",
            agent=agent,
            async_execution=True,
            expected_output='''
CostSavingOpportunities(
    potential_savings={"Cloud Services": 20000.0, "Office Space Reduction": 15000.0},
    recommendations=["Switch to hybrid work model", "Optimize cloud storage usage"]
)
''',
            chat_message_id=chat_message_id
        )

    def predictive_cost_task(self, agent, chat_message_id):
        return Task(
            description="Conduct predictive cost analysis using AI and financial modeling.",
            agent=agent,
            async_execution=True,
            expected_output='''
PredictiveCostAnalysis(
    ai_model_used="LSTM Neural Network",
    predicted_cost_trends={"Q2 2025": 95000.0, "Q3 2025": 98000.0}
)
''',
            chat_message_id=chat_message_id
        )

    
    def find_initial_information_task(self, agent, chat_message_id):
        return Task(
            description="""
            Ensure to track and update the `task_status` for each agent dynamically.
            Ensure to fill out the required information about the agents' progress.
            You must update the `task_status` for each task dynamically based on completion.

            class BudgetingForecastingTaskStatus(BaseModel):
                budget_template_task_status: Optional[str] = Field(None, description="Status of Budget Template Preparation Task")
                trend_analysis_task_status: Optional[str] = Field(None, description="Status of Trend Analysis Task")
                budget_approval_workflow_task_status: Optional[str] = Field(None, description="Status of Automated Budget Approval Workflow Task")
                revenue_forecast_task_status: Optional[str] = Field(None, description="Status of Revenue Forecasting Task")
                financial_projection_task_status: Optional[str] = Field(None, description="Status of Multi-Scenario Financial Projection Task")
                capex_opex_forecast_task_status: Optional[str] = Field(None, description="Status of CAPEX and OPEX Forecasting Task")
                budget_utilization_monitoring_task_status: Optional[str] = Field(None, description="Status of Budget Utilization Monitoring Task")
                market_trend_adjustment_task_status: Optional[str] = Field(None, description="Status of Market Trend-Based Forecast Adjustment Task")
                cost_saving_suggestions_task_status: Optional[str] = Field(None, description="Status of Cost-Saving Opportunities Analysis Task")
                predictive_cost_analysis_task_status: Optional[str] = Field(None, description="Status of Predictive Cost Analysis Task")

            If any agent's task is completed, update their `task_status` to "COMPLETED".
            If any agent fails, update their `task_status` to "FAILED".

            If key financial data is missing, update all tasks related to financial projections and forecasting as "FAILED".
            """,
            agent=agent,
            expected_output="""
            - Dynamically update the `BudgetingForecastingTaskStatus` model with the latest task status.
            - If any information is unavailable, leave the task status as "FAILED".
            """,
            chat_message_id=chat_message_id
    )
