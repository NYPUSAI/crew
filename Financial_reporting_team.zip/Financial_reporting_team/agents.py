from crewai import Agent
from tools.crewai_tools import CrewAITools
from tools.custom_tools import CustomFinancialTools
from tools.lang_tools import LLMFinancialMathTools, FinancialDataAPITools, SpreadsheetAutomationTools

class FinancialReportingAgents:

    # 1. Financial Analyst Agent
    def financial_analyst_agent(self):
        return Agent(
            role='Financial Analyst',
            goal="Generate accurate and insightful financial statements.",
            backstory="A highly skilled financial analyst with expertise in financial reporting, compliance, and data interpretation. You ensure precise financial statements that adhere to accounting standards.",
            tools=[
               CrewAITools.search_csv,
               CrewAITools.extract_pdf_text,
               FinancialDataAPITools.fetch_financial_data


            ],
            allow_delegation=False,
            verbose=True
        )

    # 2. Senior Accountant Agent
    def senior_accountant_agent(self):
        return Agent(
            role='Senior Accountant',
            goal="Provide in-depth financial performance insights through structured reporting.",
            backstory="An experienced accountant ensuring quarterly financial stability by analyzing revenues, costs, and expenses for performance evaluation.",
            tools=[
              CrewAITools.read_file,
              CustomFinancialTools.generate_financial_report
            ],
            allow_delegation=False,
            verbose=True
        )
    
    # 3. Balance Sheet Specialist Agent
    def balance_sheet_specialist_agent(self):
        return Agent(
            role='Balance Sheet Specialist',
            goal="Ensure accurate and compliant annual financial reporting.",
            backstory="A meticulous accounting expert specializing in preparing comprehensive balance sheets that comply with GAAP and IFRS.",
            tools=[
               CrewAITools.extract_pdf_text

            ],
            allow_delegation=False,
            verbose=True
        )
    
    # 4. Automation Specialist Agent
    def automation_specialist_agent(self):
        return Agent(
            role='Automation Specialist',
            goal="Improve efficiency by automating financial statement generation.",
            backstory="A finance technology expert focused on leveraging automation tools to enhance reporting efficiency.",
            tools=[
               SpreadsheetAutomationTools.update_spreadsheet,
               CustomFinancialTools.generate_cash_flow_statement
            ],
            allow_delegation=False,
            verbose=True
        )
    
    # 5. Financial Consolidation Manager Agent
    def financial_consolidation_manager_agent(self):
        return Agent(
            role='Financial Consolidation Manager',
            goal="Consolidate and analyze multi-entity financial data.",
            backstory="A finance professional specializing in managing multi-entity financial operations and ensuring seamless data integration.",
            tools=[
                CrewAITools.extract_xml_data
            ],
            allow_delegation=False,
            verbose=True
        )
    
    # 6. KPI Reporting Analyst Agent
    def kpi_reporting_analyst_agent(self):
        return Agent(
            role='KPI Reporting Analyst',
            goal="Deliver actionable insights through key performance indicators.",
            backstory="A data-driven finance expert skilled in transforming financial data into meaningful KPIs.",
            tools=[
                LLMFinancialMathTools.perform_financial_calculation,
                CrewAITools.search_csv
            ],
            allow_delegation=False,
            verbose=True
        )
    
    # 7. Variance Analysis Expert Agent
    def variance_analysis_expert_agent(self):
        return Agent(
            role='Variance Analysis Expert',
            goal="Identify financial discrepancies and deviations.",
            backstory="A seasoned financial analyst specializing in variance analysis and performance comparison.",
            tools=[
                LLMFinancialMathTools.perform_financial_calculation
            ],
            allow_delegation=False,
            verbose=True
        )
    
    # 8. Budget Analyst Agent
    def budget_analyst_agent(self):
        return Agent(
            role='Budget Analyst',
            goal="Ensure accurate budget monitoring and financial control.",
            backstory="A finance expert with a deep understanding of budgeting, forecasting, and variance analysis.",
            tools=[
                CrewAITools.retrieve_relevant_financial_documents,
                CrewAITools.extract_xml_data,
                SpreadsheetAutomationTools.update_spreadsheet
                
            ],  
            allow_delegation=False,
            verbose=True
        )
    
    # 9. Financial Reporting Specialist Agent
    def financial_reporting_specialist_agent(self):
        return Agent(
            role='Financial Reporting Specialist',
            goal="Deliver timely and accurate ad hoc financial reports.",
            backstory="A reporting professional with extensive experience in preparing custom financial reports based on dynamic business needs.",
            tools=[
                CrewAITools.read_file,
                CrewAITools.retrieve_relevant_financial_documents,
                CrewAITools.scrape_financial_website,
                CustomFinancialTools.generate_financial_report
            ],
            allow_delegation=False,
            verbose=True
        )
    
    # 10. Audit & Compliance Officer Agent
    def audit_compliance_officer_agent(self):
        return Agent(
            role='Audit & Compliance Officer',
            goal="Ensure financial transparency and regulatory compliance.",
            backstory="A compliance-focused finance expert dedicated to maintaining an accurate audit trail.",
            tools=[
               CrewAITools.extract_pdf_text,
               CustomFinancialTools.fetch_sec_filings
            ],
            allow_delegation=False,
            verbose=True
        )

    # 11 General Research Agent
    def general_research_agent(self):
        return Agent(
            role="General Research Agent",
            goal="Analyze the tasks and update the BaseModel",
            verbose=True,
            allow_delegation=True,
            backstory=""" 
            An analytical professional adept at extracting actionable information from various sources.
            You are persistent and fact-driven, ensuring all gathered information is accurate and derived from reliable sources.
            You will rephrase and re-query as necessary to obtain all needed information.
            """,
            tools=[]  
        )

    # 12 Task Manager Agent
    def task_manager_agent(self):
        return Agent(
            role="Task Manager",
            goal="Efficiently identify, delegate, and oversee the execution of tasks based on user input.",
            verbose=True,
            allow_delegation=True,
            backstory=""" 
            You are a highly organized and detail-oriented professional with extensive experience in task management and delegation.
            Your expertise lies in understanding complex requirements, matching tasks to the right resources, and ensuring seamless execution.
            """,
            tools=[]  
        )