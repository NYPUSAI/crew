import json
import os
import requests
from datetime import datetime
import pandas as pd
from langchain.tools import tool

class CustomFinancialTools:
    
    @tool("EDGAR Scraper Tool")
    def fetch_sec_filings(company_ticker, filing_type="10-K", year=None):
        """Extracts 10-K and 10-Q filings from the SEC EDGAR database for regulatory compliance."""
        base_url = "https://data.sec.gov/submissions/"
        headers = {"User-Agent": "CustomFinancialBot/1.0"}

        # Construct URL to fetch company filings
        company_url = f"{base_url}CIK{company_ticker}.json"
        response = requests.get(company_url, headers=headers)

        if response.status_code != 200:
            return f"Error fetching SEC filings: {response.status_code}"
        
        filings = response.json().get("filings", {}).get("recent", {})
        
        # Filter filings based on type and year
        extracted_filings = []
        for i, form in enumerate(filings["form"]):
            if form == filing_type:
                if year and str(year) not in filings["filingDate"][i]:
                    continue
                extracted_filings.append({
                    "filing_date": filings["filingDate"][i],
                    "document_url": f"https://www.sec.gov{filings["primaryDocument"][i]}"
                })
        
        return extracted_filings if extracted_filings else "No filings found."

    @tool("Automated Report Generator")
    def generate_financial_report(data_path, report_type, output_path="financial_report.xlsx"):
        """Compiles financial data into formatted reports (P&L, Balance Sheets, etc.)."""
        df = pd.read_excel(data_path)

        if report_type == "P&L":
            report = df.groupby("Category")["Amount"].sum()
        elif report_type == "Balance Sheet":
            report = df.groupby("Account Type")["Amount"].sum()
        else:
            return "Unsupported report type. Use 'P&L' or 'Balance Sheet'."

        report.to_excel(output_path)
        return f"{report_type} report generated and saved to {output_path}"

    @tool("Cash Flow Automation Script")
    def generate_cash_flow_statement(transaction_data_path, output_path="cash_flow_statement.xlsx"):
        """Uses Python to generate automated cash flow statements from real-time transaction data."""
        df = pd.read_csv(transaction_data_path)

        # Categorizing transactions
        df["Category"] = df["Description"].apply(lambda x: "Operating" if "revenue" in x.lower() else "Investing" if "investment" in x.lower() else "Financing")
        cash_flow_summary = df.groupby("Category")["Amount"].sum()

        cash_flow_summary.to_excel(output_path)
        return f"Cash flow statement generated and saved to {output_path}"