import json
import os
import csv
import PyPDF2
import requests
from bs4 import BeautifulSoup
from xml.etree import ElementTree as ET
from langchain.tools import tool

class CrewAITools:
    
    @tool("CSVSearchTool")
    def search_csv(file_path: str, search_term: str):
        """Searches and extracts financial data from CSV reports."""
        if not os.path.exists(file_path):
            return f"Error: File {file_path} not found."
        
        results = []
        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                if search_term.lower() in str(row).lower():
                    results.append(row)
        
        return results if results else "No matching transactions found."

    @tool("PDFSearchTool")
    def extract_pdf_text(file_path: str):
        """Extracts and processes financial data from PDFs, such as audit reports and balance sheets."""
        if not os.path.exists(file_path):
            return f"Error: File {file_path} not found."
        
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            text = "\n".join([page.extract_text() for page in reader.pages if page.extract_text()])
        
        return text if text else "No text found in PDF."
    
    @tool("FileReadTool")
    def read_file(file_path: str):
        """Reads structured financial reports and extracts required information."""
        if not os.path.exists(file_path):
            return f"Error: File {file_path} not found."
        
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    @tool("SerperDevTool")
    def search_internet(query: str):
        """Retrieves financial market trends, stock updates, and economic indicators from the web."""
        top_result_to_return = 4
        url = "https://google.serper.dev/search"
        payload = json.dumps({"q": query})
        headers = {
            'X-API-KEY': os.environ.get('SERPER_API_KEY', ''),
            'content-type': 'application/json'
        }
        
        response = requests.post(url, headers=headers, data=payload)
        if response.status_code != 200:
            return "Error retrieving search results."
        
        data = response.json()
        if 'organic' not in data:
            return "No results found. Check API key or query."
        
        results = data['organic'][:top_result_to_return]
        return "\n".join([f"Title: {r['title']}\nLink: {r['link']}\nSnippet: {r['snippet']}\n" for r in results])
    
    @tool("RagTool")
    def retrieve_relevant_financial_documents(doc_path: str, search_query: str):
        """Retrieves and summarizes relevant financial documents for reporting."""
        if not os.path.exists(doc_path):
            return f"Error: File {doc_path} not found."
        
        with open(doc_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if search_query.lower() in content.lower():
            return content[:2000]  # Returning a summarized version
        else:
            return "No relevant data found in document."
    
    @tool("SeleniumScrapingTool")
    def scrape_financial_website(url: str):
        """Automates data extraction from financial news and regulatory sites."""
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            return f"Error: Unable to access {url}. Status Code: {response.status_code}"
        
        soup = BeautifulSoup(response.text, 'html.parser')
        text = soup.get_text(separator='\n')
        return text[:2000] if text else "No relevant data found on the page."
    
    @tool("XMLSearchTool")
    def extract_xml_data(file_path: str, tag: str):
        """Extracts structured data from XML-based financial reports."""
        if not os.path.exists(file_path):
            return f"Error: File {file_path} not found."
        
        tree = ET.parse(file_path)
        root = tree.getroot()
        
        results = [elem.text for elem in root.iter(tag)]
        return results if results else "No matching XML data found."
