import json
import os
import requests
import openpyxl
from langchain.tools import tool
from sympy import sympify

# LLM Math Tool
class LLMFinancialMathTools:
    
    @tool("Perform financial calculations")
    def perform_financial_calculation(expression: str):
        """Solves complex financial equations, useful for variance analysis and KPI computation."""
        try:
            result = sympify(expression).evalf()
            return result
        except Exception as e:
            return f"Error in financial calculation: {e}"


# Financial Data API Tool
class FinancialDataAPITools:
    
    @tool("Retrieve financial market data")
    def fetch_financial_data(api_url: str, params: dict):
        """Fetches financial statements and market data from external APIs like Alpha Vantage or Yahoo Finance."""
        try:
            response = requests.get(api_url, params=params)
            if response.status_code == 200:
                return response.json()
            else:
                return f"Error fetching financial data. Status Code: {response.status_code}"
        except Exception as e:
            return f"Error in API request: {e}"


# Spreadsheet Automation Tool
class SpreadsheetAutomationTools:
    
    @tool("Update Excel spreadsheets with financial data")
    def update_spreadsheet(file_path: str, sheet_name: str, data: list):
        """Automates updates to Excel spreadsheets for financial tracking and reporting."""
        try:
            if not os.path.exists(file_path):
                return "Error: Spreadsheet file not found."
            
            wb = openpyxl.load_workbook(file_path)
            if sheet_name not in wb.sheetnames:
                return "Error: Sheet not found in workbook."
            
            sheet = wb[sheet_name]
            for row in data:
                sheet.append(row)
            
            wb.save(file_path)
            return "Spreadsheet updated successfully."
        except Exception as e:
            return f"Error updating spreadsheet: {e}"
