from crewai import Crew, Process
from langchain_openai import ChatOpenAI
from agents import FinancialReportingAgents
from tasks import FinancialReportTask
from dotenv import load_dotenv
from crewai import Task

load_dotenv()

# Initialize the agents and tasks
agents = FinancialReportingAgents()
tasks = FinancialReportTask()

# Initialize the OpenAI GPT-3.5 language model
manager_llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7)

# Instantiate the agents
financial_analyst_agent = agents.financial_analyst_agent()
senior_accountant_agent = agents.senior_accountant_agent()
balance_sheet_specialist_agent = agents.balance_sheet_specialist_agent()
automation_specialist_agent = agents.automation_specialist_agent()
financial_consolidation_manager_agent = agents.financial_consolidation_manager_agent()
kpi_reporting_analyst_agent = agents.kpi_reporting_analyst_agent()
variance_analysis_expert_agent = agents.variance_analysis_expert_agent()
budget_analyst_agent = agents.budget_analyst_agent()
financial_reporting_specialist_agent = agents.financial_reporting_specialist_agent()
audit_compliance_officer_agent = agents.audit_compliance_officer_agent()
general_research_agent = agents.general_research_agent()
task_manager_agent = agents.task_manager_agent()

# Instantiate the tasks
financial_statement_task = tasks.financial_statement_task(financial_analyst_agent, 1111)
quarterly_pnl_task = tasks.quarterly_pnl_task(senior_accountant_agent, 2222)
annual_balance_sheet_task = tasks.annual_balance_sheet_task(balance_sheet_specialist_agent, 3333)
cash_flow_statement_task = tasks.cash_flow_statement_task(automation_specialist_agent, 4444)
variance_analysis_task = tasks.variance_analysis_task(variance_analysis_expert_agent, 5555)
financial_data_consolidation_task = tasks.financial_data_consolidation_task(financial_consolidation_manager_agent, 6666)
kpi_dashboard_task = tasks.kpi_dashboard_task(kpi_reporting_analyst_agent, 7777)
budget_comparison_task = tasks.budget_comparison_task(budget_analyst_agent, 8888)
audit_trail_generation_task = tasks.audit_trail_generation_task(audit_compliance_officer_agent, 9999)
find_initial_information_task = tasks.find_initial_information_task(task_manager_agent, 10000)

# Define inputs
inputs = {
    "company_name": "XYZ Corporation",
    "location": "New York",
    
    # Financial Statements Data
    "trial_balance_path": "Financial_Inputs/Trial_Balance/trial_balance_feb2025.xlsx",
    "general_ledger_path": "Financial_Inputs/General_Ledger/general_ledger_2025.sql",
    "adjustments_entries_path": "Financial_Inputs/Adjustments/adjustments_feb2025.json",
    
    # Profit & Loss and Balance Sheet Data
    "revenue_data_path": "Financial_Inputs/Revenue/revenue_feb2025.csv",
    "expense_data_path": "Financial_Inputs/Expenses/expenses_feb2025.xlsx",
    "depreciation_data_path": "Financial_Inputs/Depreciation/depreciation_schedule_2025.json",
    "loan_liability_data_path": "Financial_Inputs/Liabilities/loan_liabilities_feb2025.xlsx",
    "investment_data_path": "Financial_Inputs/Assets/investment_holdings_2025.csv",
    
    # Cash Flow & Multi-Entity Data
    "cash_inflow_data_path": "Financial_Inputs/Cash_Flow/cash_inflows_feb2025.json",
    "cash_outflow_data_path": "Financial_Inputs/Cash_Flow/cash_outflows_feb2025.json",
    "multi_entity_financials_path": "Financial_Inputs/Consolidation/multi_entity_financials_2025.xlsx",
    "currency_exchange_rates_path": "Financial_Inputs/Consolidation/exchange_rates_feb2025.json",

    # KPI & Variance Analysis Data
    "kpi_definitions_path": "Financial_Inputs/KPIs/kpi_definitions.json",
    "forecasted_financials_path": "Financial_Inputs/Forecasts/forecasted_financials_2025.xlsx",
    "actual_financials_path": "Financial_Inputs/Actuals/actual_financials_feb2025.xlsx",

    # Budgeting Data
    "budget_allocation_path": "Financial_Inputs/Budget/budget_allocation_2025.xlsx",
    "actual_expenditure_path": "Financial_Inputs/Budget/actual_expenditure_feb2025.xlsx",

    # Compliance & Audit Trail Data
    "audit_logs_path": "Financial_Inputs/Audit_Trails/audit_logs_2025.json",
    "regulatory_compliance_path": "Financial_Inputs/Compliance/regulatory_compliance_2025.pdf",

    # Ad Hoc Reports & Automation Settings
    "custom_report_queries_path": "Financial_Inputs/Ad_Hoc_Reports/custom_report_queries.json",
    "report_scheduling_settings_path": "Financial_Inputs/Automation_Settings/report_scheduling.json",
}


process_pending_tasks_task = Task(
    description=(
    """
    Take the task provided by the user (`{human_task}`) and determine which agent is best suited to execute it based on the agent's role and capabilities.

    Steps to follow:
    1. **Analyze the Task**: Carefully read and understand the task provided by the user. Identify the key requirements and objectives of the task.
    2. **Match Task to Agent**: Review the roles and capabilities of all available agents. Match the task to the most appropriate agent based on their expertise and tools.
    3. **Delegate the Task**: If a suitable agent is found, delegate the task to that agent and ensure they execute it properly. Provide the agent with all necessary information and context.
    4. **Handle Unmatched Tasks**: If no suitable agent is available to handle the task, inform the user that the task cannot be executed and provide a reason why.
    5. **Monitor Progress**: Continuously monitor the progress of the task. If the task fails or encounters issues, update the task status accordingly and inform the user.
    6. **Ensure Completion**: Once the task is completed, verify that the output meets the user's expectations and update the task status to "COMPLETED".

    Ensure that all tasks are executed efficiently and that the user is kept informed of the progress and any issues that arise.
    """
    ),
    expected_output="""
    The task provided by the user should be executed by the appropriate agent, and the results should be returned to the user.
    If the task cannot be executed, the user should be informed with a clear explanation.
    The task status should be updated dynamically based on the progress and outcome of the task.
    """,

) 
# Crew setup for sequential processing
crew = Crew(
    agents=[
        financial_analyst_agent,
        senior_accountant_agent,
        balance_sheet_specialist_agent,
        automation_specialist_agent,
        financial_consolidation_manager_agent,
        kpi_reporting_analyst_agent,
        variance_analysis_expert_agent,
        budget_analyst_agent,
        financial_reporting_specialist_agent,
        audit_compliance_officer_agent,
        general_research_agent,
        task_manager_agent
    ],
    tasks=[
        financial_statement_task,
        quarterly_pnl_task,
        annual_balance_sheet_task,
        cash_flow_statement_task,
        variance_analysis_task,
        financial_data_consolidation_task,
        kpi_dashboard_task,
        budget_comparison_task,
        audit_trail_generation_task,
        find_initial_information_task
    ],
    process=Process.sequential
)

# Execute crew
result = crew.kickoff()
print(result)

# Crew setup for hierarchical human task management
human_task_crew = Crew(
    agents=[
        financial_analyst_agent,
        senior_accountant_agent,
        balance_sheet_specialist_agent,
        automation_specialist_agent,
        financial_consolidation_manager_agent,
        kpi_reporting_analyst_agent,
        variance_analysis_expert_agent,
        budget_analyst_agent,
        financial_reporting_specialist_agent,
        audit_compliance_officer_agent,
        general_research_agent,
        task_manager_agent
    ],
    tasks=[find_initial_information_task],
    process=Process.hierarchical,
    manager_llm=manager_llm,
    verbose=True,
    manager_agent=agents.task_manager_agent()
)

human_inputs = {
    "human_task": "Generate a compliance summary for the latest regulatory reports."
}

human_result = human_task_crew.kickoff()
print(human_result)
