from pydantic import BaseModel, Field
from crewai import Task
from typing import Optional, List, Dict, Literal
from langchain.tools import BaseTool

class FinancialStatement(BaseModel):
    period: str
    total_revenue: float
    total_expenses: float
    net_profit: float

class QuarterlyPnL(BaseModel):
    revenue_breakdown: Dict[str, float]
    expense_breakdown: Dict[str, float]
    net_profit: float

class AnnualBalanceSheet(BaseModel):
    assets: Dict[str, float]
    liabilities: Dict[str, float]
    equity: float

class CashFlowReport(BaseModel):
    operating_cash_flow: float
    investing_cash_flow: float
    financing_cash_flow: float
    net_cash_flow: float

class VarianceAnalysis(BaseModel):
    budgeted_amount: float
    actual_amount: float
    variance: float
    variance_reason: str

class FinancialDataConsolidation(BaseModel):
    entities_included: List[str]
    consolidated_report: str

class KPIDashboard(BaseModel):
    key_metrics: Dict[str, float]
    insights: str

class BudgetComparison(BaseModel):
    budget_vs_actual: Dict[str, float]
    variance_analysis: Dict[str, str]

class AuditTrail(BaseModel):
    transactions_logged: int
    compliance_status: str

class TaskStatusUpdateSchema(BaseModel):
    task_name: str = Field(..., description="The name of the task being updated.")
    status: Literal["COMPLETED", "PENDING", "FAILED"] = Field(..., description="Task status must be 'COMPLETED', 'PENDING', or 'FAILED'.")
    chat_message_id: int = Field(..., description="The ID of the chat message associated with the task.")

class TaskStatusUpdate(BaseTool):
    name: str = "task_status_update"
    description: str = "Updates the task status dynamically to either 'COMPLETED', 'PENDING', or 'FAILED' along with the task name and chat message ID."
    args_schema = TaskStatusUpdateSchema

    def _run(self, task_name: str, status: str, chat_message_id: int) -> str:
        print(f"Updated Task: {task_name} | Status: {status} for Chat Message ID: {chat_message_id}")
        return f"Task '{task_name}' status updated successfully to {status}"

class FinancialReportingTaskStatus(BaseModel):
    financial_statement_task_status: Optional[str] = Field(None, description="Status of Financial Statement Generation Task")
    quarterly_pnl_task_status: Optional[str] = Field(None, description="Status of Quarterly Profit-and-Loss Report Task")
    annual_balance_sheet_task_status: Optional[str] = Field(None, description="Status of Annual Balance Sheet Preparation Task")
    cash_flow_statement_task_status: Optional[str] = Field(None, description="Status of Cash Flow Statement Automation Task")
    financial_data_consolidation_task_status: Optional[str] = Field(None, description="Status of Multi-Entity Financial Data Consolidation Task")
    kpi_dashboard_task_status: Optional[str] = Field(None, description="Status of KPI Dashboard Generation Task")
    variance_analysis_task_status: Optional[str] = Field(None, description="Status of Variance Analysis Report Task")
    budget_comparison_task_status: Optional[str] = Field(None, description="Status of Budget-to-Actual Comparison Task")
    ad_hoc_report_task_status: Optional[str] = Field(None, description="Status of Ad Hoc Financial Report Creation Task")
    audit_trail_generation_task_status: Optional[str] = Field(None, description="Status of Automated Audit Trail Generation Task")


class FinancialReportTask:
    def financial_statement_task(self, agent, chat_message_id):
        return Task(
            description="Generate a financial statement summarizing revenue, expenses, and profit for the given period.",
            agent=agent,
            async_execution=True,
            expected_output='''FinancialStatement(period="Q1 2025", total_revenue=500000.0, total_expenses=350000.0, net_profit=150000.0)''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def quarterly_pnl_task(self, agent, chat_message_id):
        return Task(
            description="Prepare a quarterly profit and loss report with revenue and expense breakdowns.",
            agent=agent,
            async_execution=True,
            expected_output='''QuarterlyPnL(revenue_breakdown={"Product A": 300000.0, "Service B": 200000.0}, 
            expense_breakdown={"Marketing": 50000.0, "Operations": 100000.0}, net_profit=250000.0)''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def annual_balance_sheet_task(self, agent, chat_message_id):
        return Task(
            description="Generate an annual balance sheet summarizing assets, liabilities, and equity.",
            agent=agent,
            async_execution=True,
            expected_output='''AnnualBalanceSheet(assets={"Cash": 200000.0, "Equipment": 500000.0}, 
            liabilities={"Loans": 150000.0, "Payables": 50000.0}, equity=500000.0)''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def cash_flow_statement_task(self, agent, chat_message_id):
        return Task(
            description="Automate the preparation of a cash flow statement.",
            agent=agent,
            async_execution=True,
            expected_output='''CashFlowReport(operating_cash_flow=100000.0, investing_cash_flow=-50000.0, financing_cash_flow=20000.0, net_cash_flow=70000.0)''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def variance_analysis_task(self, agent, chat_message_id):
        return Task(
            description="Analyze budget-to-actual financial variances and identify causes.",
            agent=agent,
            async_execution=True,
            expected_output='''VarianceAnalysis(budgeted_amount=200000.0, actual_amount=180000.0, variance=-20000.0, variance_reason="Higher marketing spend")''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def financial_data_consolidation_task(self, agent, chat_message_id):
        return Task(
            description="Consolidate financial data from multiple entities into a unified report.",
            agent=agent,
            async_execution=True,
            expected_output='''FinancialDataConsolidation(entities_included=["Subsidiary A", "Subsidiary B"], consolidated_report="Unified financial report generated successfully.")''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def kpi_dashboard_task(self, agent, chat_message_id):
        return Task(
            description="Generate a KPI dashboard with financial performance metrics.",
            agent=agent,
            async_execution=True,
            expected_output='''KPIDashboard(key_metrics={"Gross Margin": 0.45, "Operating Income": 150000.0}, insights="Positive revenue trend with stable cost control.")''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def budget_comparison_task(self, agent, chat_message_id):
        return Task(
            description="Compare actual financial performance against budgeted targets.",
            agent=agent,
            async_execution=True,
            expected_output='''BudgetComparison(budget_vs_actual={"Revenue": "10% increase", "Expenses": "5% higher than expected"}, variance_analysis={"Marketing Spend": "Exceeded budget by 15%"})''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def audit_trail_generation_task(self, agent, chat_message_id):
        return Task(
            description="Automatically generate an audit trail for financial transactions.",
            agent=agent,
            async_execution=True,
            expected_output='''AuditTrail(transactions_logged=500, compliance_status="Fully Compliant")''',
            tools=[TaskStatusUpdate()],
            chat_message_id=chat_message_id
        )

    def find_initial_information_task(self, agent, chat_message_id):
        return Task(
            description="""Ensure to track and update the `task_status` for each agent dynamically.
        Ensure to fill out the required information about the agents' progress.
        You must update the `task_status` for each task dynamically based on completion.

        class FinancialReportingTaskStatus(BaseModel):
            financial_statement_task_status: Optional[str] = Field(None, description="Status of Financial Statement Generation Task")
            quarterly_pnl_task_status: Optional[str] = Field(None, description="Status of Quarterly Profit-and-Loss Report Task")
            annual_balance_sheet_task_status: Optional[str] = Field(None, description="Status of Annual Balance Sheet Preparation Task")
            cash_flow_statement_task_status: Optional[str] = Field(None, description="Status of Cash Flow Statement Automation Task")
            financial_data_consolidation_task_status: Optional[str] = Field(None, description="Status of Multi-Entity Financial Data Consolidation Task")
            kpi_dashboard_task_status: Optional[str] = Field(None, description="Status of KPI Dashboard Generation Task")
            variance_analysis_task_status: Optional[str] = Field(None, description="Status of Variance Analysis Report Task")
            budget_comparison_task_status: Optional[str] = Field(None, description="Status of Budget-to-Actual Comparison Task")
            ad_hoc_report_task_status: Optional[str] = Field(None, description="Status of Ad Hoc Financial Report Creation Task")
            audit_trail_generation_task_status: Optional[str] = Field(None, description="Status of Audit Trail Generation Task")

        If any agent's task is completed, update their `task_status` to "COMPLETED".
        If any agent fails, update their `task_status` to "FAILED".

        If the financial data is missing, update all tasks from variance analysis as "FAILED".
        """,
            agent=agent,
            expected_output="""- Dynamically update the `FinancialReportingTaskStatus` model with the latest task status.
        - If any information is unavailable, leave it as "FAILED".
        """,
            chat_message_id=chat_message_id
    )

    